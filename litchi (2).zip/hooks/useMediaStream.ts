
import { useState, useEffect, useRef } from 'react';

interface UseMediaStreamResult {
    stream: MediaStream | null;
    error: string | null;
    isLoading: boolean;
}

export type StreamSource = 'camera' | 'screen';

export const useMediaStream = (source: StreamSource = 'camera', onEnded?: () => void): UseMediaStreamResult => {
    const [stream, setStream] = useState<MediaStream | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const streamRef = useRef<MediaStream | null>(null);
    const audioContextRef = useRef<AudioContext | null>(null);

    useEffect(() => {
        let isMounted = true;
        const getMedia = async () => {
            setIsLoading(true);
            try {
                let mediaStream: MediaStream;

                if (source === 'screen') {
                    // 1. Get the screen stream (video + optional system audio)
                    const screenStream = await navigator.mediaDevices.getDisplayMedia({
                        video: {
                            cursor: "always"
                        } as any,
                        audio: true,
                    });

                    try {
                        // 2. Try to get microphone audio to merge
                        const micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
                        
                        // 3. Merge audio tracks using AudioContext
                        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
                        audioContextRef.current = audioContext;
                        const destination = audioContext.createMediaStreamDestination();

                        // Mic Source
                        const micSource = audioContext.createMediaStreamSource(micStream);
                        micSource.connect(destination);

                        // System Audio Source (if available from screen share)
                        if (screenStream.getAudioTracks().length > 0) {
                            const systemSource = audioContext.createMediaStreamSource(new MediaStream([screenStream.getAudioTracks()[0]]));
                            systemSource.connect(destination);
                        }

                        // 4. Create the final combined stream
                        mediaStream = new MediaStream([
                            ...screenStream.getVideoTracks(),
                            ...destination.stream.getAudioTracks()
                        ]);

                        // Keep references to tracks for cleanup
                        const allTracks = [...screenStream.getTracks(), ...micStream.getTracks()];
                        allTracks.forEach(track => {
                            track.onended = () => {
                                if (onEnded) onEnded();
                            };
                        });
                    } catch (micErr) {
                        console.warn("Microphone access denied for screen share, using system audio only.");
                        mediaStream = screenStream;
                        mediaStream.getTracks().forEach(track => {
                            track.onended = () => {
                                if (onEnded) onEnded();
                            };
                        });
                    }
                } else {
                    mediaStream = await navigator.mediaDevices.getUserMedia({
                        video: { facingMode: "user" },
                        audio: true,
                    });
                    mediaStream.getTracks().forEach(track => {
                        track.onended = () => {
                            if (onEnded) onEnded();
                        };
                    });
                }
                
                if (isMounted) {
                    streamRef.current = mediaStream;
                    setStream(mediaStream);
                    setError(null);
                }
            } catch (err) {
                if (isMounted) {
                    if (err instanceof Error) {
                        setError(`Error accessing ${source}: ${err.message}`);
                    } else {
                        setError(`An unknown error occurred while accessing the ${source}.`);
                    }
                }
            } finally {
                if (isMounted) {
                    setIsLoading(false);
                }
            }
        };

        getMedia();

        return () => {
            isMounted = false;
            if (streamRef.current) {
                streamRef.current.getTracks().forEach(track => {
                    track.onended = null;
                    track.stop();
                });
            }
            if (audioContextRef.current) {
                audioContextRef.current.close();
            }
        };
    }, [source, onEnded]);

    return { stream, error, isLoading };
};
