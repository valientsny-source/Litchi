
import { useState, useEffect, useRef } from 'react';

interface UseCameraResult {
    stream: MediaStream | null;
    error: string | null;
    isLoading: boolean;
}

export const useCamera = (): UseCameraResult => {
    const [stream, setStream] = useState<MediaStream | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const streamRef = useRef<MediaStream | null>(null);

    useEffect(() => {
        let isMounted = true;
        const getMedia = async () => {
            try {
                const mediaStream = await navigator.mediaDevices.getUserMedia({
                    video: { facingMode: "user" },
                    audio: true,
                });
                if (isMounted) {
                    streamRef.current = mediaStream;
                    setStream(mediaStream);
                    setError(null);
                }
            } catch (err) {
                if (isMounted) {
                    if (err instanceof Error) {
                        setError(`Error accessing camera: ${err.message}`);
                    } else {
                        setError("An unknown error occurred while accessing the camera.");
                    }
                }
            } finally {
                if (isMounted) {
                    setIsLoading(false);
                }
            }
        };

        getMedia();

        return () => {
            isMounted = false;
            if (streamRef.current) {
                streamRef.current.getTracks().forEach(track => track.stop());
            }
        };
    }, []);

    return { stream, error, isLoading };
};
