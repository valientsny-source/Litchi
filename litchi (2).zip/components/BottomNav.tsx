
import React from 'react';
import type { View } from '../types';
import { useApp } from '../contexts/AppContext';

interface BottomNavProps {
    currentView: View;
    navigate: (view: View) => void;
}

const NavItem: React.FC<{ icon: React.ReactNode, label: string, isActive: boolean, onClick: () => void }> = ({ icon, label, isActive, onClick }) => (
    <button onClick={onClick} className={`flex flex-col items-center justify-center w-full pt-2 pb-1 text-sm transition-colors duration-200 ${isActive ? 'text-purple-400' : 'text-gray-400 hover:text-white'}`}>
        {icon}
        <span className="mt-1 text-[10px] uppercase font-black tracking-widest">{label}</span>
    </button>
);

const HomeIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
    </svg>
);

const FollowingIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
    </svg>
);

const ProfileIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
    </svg>
);

const AdminIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
    </svg>
);

const BottomNav: React.FC<BottomNavProps> = ({ currentView, navigate }) => {
    const { currentUser } = useApp();
    
    return (
        <nav className="fixed bottom-0 left-0 right-0 h-16 bg-gray-900 border-t border-gray-700 flex justify-around items-center z-50 md:hidden">
            <NavItem
                icon={<HomeIcon />}
                label="Home"
                isActive={currentView === 'home'}
                onClick={() => navigate('home')}
            />
            <NavItem
                icon={<FollowingIcon />}
                label="Following"
                isActive={currentView === 'following'}
                onClick={() => navigate('following')}
            />
            <NavItem
                icon={<ProfileIcon />}
                label={currentUser ? "Profile" : "Login"}
                isActive={currentView === 'profile'}
                onClick={() => navigate('profile')}
            />
            {currentUser?.isAdmin && (
                <NavItem
                    icon={<AdminIcon />}
                    label="Admin"
                    isActive={currentView === 'admin'}
                    onClick={() => navigate('admin')}
                />
            )}
        </nav>
    );
};

export default BottomNav;
