
import React, { useState } from 'react';

interface ScheduleModalProps {
    onClose: () => void;
    onSchedule: (date: Date, duration: number | null, recurrence: 'daily' | 'weekly' | null) => void;
}

type Recurrence = 'daily' | 'weekly' | null;

const ScheduleModal: React.FC<ScheduleModalProps> = ({ onClose, onSchedule }) => {
    const [dateTime, setDateTime] = useState('');
    const [duration, setDuration] = useState<string>('60');
    const [recurrence, setRecurrence] = useState<Recurrence>(null);

    const handleSchedule = () => {
        if (dateTime) {
            const durationNum = duration ? parseInt(duration, 10) : null;
            onSchedule(new Date(dateTime), durationNum, recurrence);
            onClose();
        }
    };

    const RecurrenceButton: React.FC<{ value: Recurrence, label: string }> = ({ value, label }) => (
        <button
            onClick={() => setRecurrence(value)}
            className={`flex-1 px-4 py-2 text-sm font-semibold rounded-md transition-colors ${
                recurrence === value
                    ? 'bg-purple-600 text-white'
                    : 'bg-gray-600 text-gray-300 hover:bg-gray-500'
            }`}
        >
            {label}
        </button>
    );

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 p-4">
            <div className="bg-gray-800 rounded-lg shadow-xl p-6 w-full max-w-sm">
                <h2 className="text-2xl font-bold mb-4 text-white">Schedule Live Stream</h2>
                <p className="text-gray-400 mb-6">Choose a date, time, duration, and recurrence for your broadcast.</p>
                
                <label htmlFor="datetime" className="block text-sm font-medium text-gray-300">Start Time</label>
                <input
                    id="datetime"
                    type="datetime-local"
                    value={dateTime}
                    onChange={(e) => setDateTime(e.target.value)}
                    className="w-full mt-1 p-3 bg-gray-700 border border-gray-600 rounded-md text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none"
                    min={new Date().toISOString().slice(0, 16)}
                />

                <label htmlFor="duration" className="block text-sm font-medium text-gray-300 mt-4">Duration (minutes)</label>
                <input
                    type="number"
                    id="duration"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    className="w-full mt-1 p-3 bg-gray-700 border border-gray-600 rounded-md text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none"
                    placeholder="e.g., 60"
                    min="1"
                />

                <label className="block text-sm font-medium text-gray-300 mt-4">Recurrence</label>
                <div className="flex space-x-2 mt-2">
                    <RecurrenceButton value={null} label="Once" />
                    <RecurrenceButton value="daily" label="Daily" />
                    <RecurrenceButton value="weekly" label="Weekly" />
                </div>

                <div className="mt-8 flex justify-end space-x-4">
                    <button
                        onClick={onClose}
                        className="px-6 py-2 rounded-md font-semibold text-gray-300 bg-gray-600 hover:bg-gray-500 transition-colors"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={handleSchedule}
                        disabled={!dateTime}
                        className="px-6 py-2 rounded-md font-semibold text-white bg-purple-600 hover:bg-purple-700 transition-colors disabled:bg-purple-800 disabled:cursor-not-allowed"
                    >
                        Schedule
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ScheduleModal;