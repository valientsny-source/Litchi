
import React from 'react';
import { useApp } from '../contexts/AppContext';
import type { View } from '../types';

interface SidebarProps {
    currentView: View;
    navigate: (view: View) => void;
}

const HomeIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
    </svg>
);

const FollowingIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
    </svg>
);

const ProfileIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
    </svg>
);

const AdminIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
    </svg>
);


const NavItem: React.FC<{ icon: React.ReactNode, label: string, isActive: boolean, onClick: () => void, color?: string }> = ({ icon, label, isActive, onClick, color = 'bg-purple-600' }) => (
    <button onClick={onClick} className={`flex items-center w-full px-4 py-3 text-sm transition-all duration-300 rounded-xl group ${isActive ? `${color} text-white shadow-[0_8px_20px_-10px_rgba(147,51,234,0.5)]` : 'text-gray-500 hover:bg-gray-900 hover:text-white'}`}>
        <div className={`p-1 rounded-lg transition-colors ${isActive ? 'bg-white/10' : 'bg-gray-800/50 group-hover:bg-gray-700'}`}>
            {icon}
        </div>
        <span className="ml-4 font-black uppercase tracking-widest text-[11px]">{label}</span>
    </button>
);

const Sidebar: React.FC<SidebarProps> = ({ currentView, navigate }) => {
    const { currentUser } = useApp();
    return (
        <nav className="hidden md:flex flex-col w-64 bg-gray-950 border-r border-gray-800 p-6 space-y-8 h-[calc(100vh-64px)] overflow-y-auto shrink-0">
            <div className="space-y-2">
                <p className="text-[10px] font-black text-gray-600 uppercase tracking-[0.2em] px-4 mb-4">Discovery</p>
                <NavItem
                    icon={<HomeIcon />}
                    label="Explore"
                    isActive={currentView === 'home'}
                    onClick={() => navigate('home')}
                />
                <NavItem
                    icon={<FollowingIcon />}
                    label="Following"
                    isActive={currentView === 'following'}
                    onClick={() => navigate('following')}
                />
            </div>

            <div className="space-y-2">
                <p className="text-[10px] font-black text-gray-600 uppercase tracking-[0.2em] px-4 mb-4">Me</p>
                <NavItem
                    icon={<ProfileIcon />}
                    label="Dashboard"
                    isActive={currentView === 'profile'}
                    onClick={() => navigate('profile')}
                />
            </div>

            {currentUser?.isAdmin && (
                <div className="pt-4 mt-4 border-t border-gray-800 space-y-2">
                    <p className="text-[10px] font-black text-emerald-600/50 uppercase tracking-[0.2em] px-4 mb-4">Management</p>
                    <NavItem
                        icon={<AdminIcon />}
                        label="Platform"
                        isActive={currentView === 'admin'}
                        onClick={() => navigate('admin')}
                        color="bg-emerald-600"
                    />
                </div>
            )}
            
            <div className="mt-auto pt-8">
                <div className="p-4 bg-gradient-to-br from-purple-900/40 to-indigo-900/40 rounded-2xl border border-purple-500/20">
                    <p className="text-xs font-bold text-white mb-2">Want to level up?</p>
                    <p className="text-[10px] text-gray-400 leading-relaxed mb-3">Upgrade your status to unlock exclusive badges and custom emoji reactions.</p>
                    <button className="w-full py-2 bg-purple-600 text-white text-[10px] font-black rounded-lg hover:bg-purple-700 transition-all uppercase tracking-tighter">Get Pro Status</button>
                </div>
                <div className="mt-6 flex flex-wrap gap-3 px-4">
                    <span className="text-[9px] font-bold text-gray-600 uppercase cursor-pointer hover:text-gray-400 transition-colors">Privacy</span>
                    <span className="text-[9px] font-bold text-gray-600 uppercase cursor-pointer hover:text-gray-400 transition-colors">Terms</span>
                    <span className="text-[9px] font-bold text-gray-600 uppercase cursor-pointer hover:text-gray-400 transition-colors">Help</span>
                </div>
            </div>
        </nav>
    );
};

export default Sidebar;
