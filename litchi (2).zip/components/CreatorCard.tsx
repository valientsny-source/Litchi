
import React from 'react';
import type { Creator, Stream } from '../types';
import { useApp } from '../contexts/AppContext';

interface CreatorCardProps {
    creator: Creator;
    onTuneIn: (creatorId: string) => void;
    onVisitChannel: (creatorId: string) => void;
}

const formatFollowers = (num: number): string => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
};

const formatScheduleTime = (stream: Stream): string => {
    if (!stream.scheduledTime) return '';
    const date = new Date(stream.scheduledTime);
    const now = new Date();

    let durationText = '';
    if (stream.durationMinutes) {
        if (stream.durationMinutes >= 60) {
            const hours = Math.floor(stream.durationMinutes / 60);
            const minutes = stream.durationMinutes % 60;
            durationText = ` for ${hours}h`;
            if (minutes > 0) {
                durationText += ` ${minutes}m`;
            }
        } else {
            durationText = ` for ${stream.durationMinutes}m`;
        }
    }
    
    if (stream.recurrence) {
        const recurrenceText = stream.recurrence.charAt(0).toUpperCase() + stream.recurrence.slice(1);
        const time = date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
        return `${recurrenceText} at ${time}${durationText}`;
    }

    const diff = date.getTime() - now.getTime();
    if (diff <= 0) return `Starting soon${durationText}`;
    
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hours > 23) {
        const days = Math.floor(hours / 24);
        return `Live in ${days}d${durationText}`;
    }
    if (hours > 0) return `Live in ${hours}h ${minutes}m${durationText}`;
    if (minutes > 0) return `Live in ${minutes}m${durationText}`;
    return `Live soon${durationText}`;
};

const CreatorCard: React.FC<CreatorCardProps> = ({ creator, onTuneIn, onVisitChannel }) => {
    const { following, toggleFollow, getStreamByCreatorId } = useApp();
    const isFollowing = following.includes(creator.id);
    const stream = getStreamByCreatorId(creator.id);

    const handleCardClick = () => {
        if (stream?.isLive) {
            onTuneIn(creator.id);
        } else {
            onVisitChannel(creator.id);
        }
    };

    return (
        <div className="bg-gray-800 rounded-lg overflow-hidden shadow-lg mb-4 transform transition-transform duration-300 hover:scale-105 border border-gray-700">
            <div
                className="p-4 flex items-center justify-between cursor-pointer"
                onClick={handleCardClick}
            >
                <div className="flex items-center">
                    <div className="relative group">
                        <img className="w-16 h-16 rounded-full border-2 border-gray-600 group-hover:border-purple-500 transition-colors" src={creator.avatar} alt={creator.name} referrerPolicy="no-referrer" loading="lazy" />
                        {stream?.isLive && (
                             <div className="absolute -bottom-1 -right-1 bg-red-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full animate-pulse border-2 border-gray-800">
                                LIVE
                            </div>
                        )}
                        {stream?.endedAt && !stream.isLive && (
                             <div className="absolute -bottom-1 -right-1 bg-blue-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full border-2 border-gray-800">
                                REPLAY
                            </div>
                        )}
                    </div>
                    <div className="ml-4">
                        <p className="font-bold text-lg text-white hover:text-purple-400 transition-colors">{creator.name}</p>
                        <p className="text-gray-400 text-xs">{formatFollowers(creator.followers)} followers • {creator.videos?.length || 0} shorts</p>
                         {stream?.scheduledTime && !stream.isLive && (
                            <p className="text-[10px] text-purple-400 font-semibold mt-1">
                                {formatScheduleTime(stream)}
                            </p>
                        )}
                        {creator.links && creator.links.length > 0 && (
                            <div className="flex space-x-2 mt-2">
                                {creator.links.slice(0, 2).map((link, index) => link.title && link.url && (
                                    <div 
                                        key={index}
                                        className="text-[10px] bg-gray-700 text-gray-400 px-2 py-0.5 rounded-full"
                                    >
                                        {link.title}
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
                <div>
                    <button
                        onClick={(e) => { e.stopPropagation(); toggleFollow(creator.id); }}
                        className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all ${isFollowing ? 'bg-purple-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'}`}
                    >
                        {isFollowing ? 'Following' : 'Follow'}
                    </button>
                </div>
            </div>
            {stream?.isLive ? (
                <div className="p-3 bg-red-500/10 border-t border-red-500/20 text-center cursor-pointer" onClick={handleCardClick}>
                    <p className="text-red-400 text-xs font-bold animate-pulse">CREATOR IS LIVE • TAP TO JOIN</p>
                </div>
            ) : stream?.endedAt ? (
                <div className="p-3 bg-blue-500/10 border-t border-blue-500/20 text-center cursor-pointer" onClick={handleCardClick}>
                    <p className="text-blue-400 text-xs font-bold uppercase tracking-widest">Watch Replay</p>
                </div>
            ) : (
                <div className="p-3 bg-gray-700/30 border-t border-gray-700 text-center cursor-pointer" onClick={handleCardClick}>
                    <p className="text-gray-400 text-xs font-semibold">VIEW CHANNEL</p>
                </div>
            )}
        </div>
    );
};

export default CreatorCard;
