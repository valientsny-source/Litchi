
import React, { useState } from 'react';
import type { ShortVideo } from '../types';

interface ShortsGalleryProps {
    videos: ShortVideo[];
}

const VideoPlayerModal: React.FC<{ video: ShortVideo; onClose: () => void }> = ({ video, onClose }) => (
    <div className="fixed inset-0 bg-black/95 z-[100] flex flex-col items-center justify-center p-4" onClick={onClose}>
        <div className="relative w-full max-w-sm aspect-[9/16] bg-black rounded-xl overflow-hidden shadow-2xl" onClick={e => e.stopPropagation()}>
            <video 
                src={video.videoUrl} 
                className="w-full h-full object-cover" 
                controls 
                autoPlay 
                loop
            />
            <button 
                onClick={onClose} 
                className="absolute top-4 right-4 bg-white/20 hover:bg-white/40 p-2 rounded-full text-white transition-colors"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
            <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/80 to-transparent">
                <h3 className="text-xl font-bold text-white">{video.title}</h3>
                <p className="text-gray-300 text-sm">Duration: {video.duration}</p>
            </div>
        </div>
    </div>
);

const ShortsGallery: React.FC<ShortsGalleryProps> = ({ videos }) => {
    const [selectedVideo, setSelectedVideo] = useState<ShortVideo | null>(null);

    return (
        <div className="mt-4">
            {videos.length === 0 ? (
                <div className="text-center py-12 bg-gray-800/30 rounded-xl border border-dashed border-gray-700">
                    <p className="text-gray-500">No shorts uploaded yet.</p>
                </div>
            ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {videos.map(video => (
                        <div 
                            key={video.id} 
                            onClick={() => setSelectedVideo(video)}
                            className="relative aspect-[9/16] rounded-lg overflow-hidden bg-gray-800 cursor-pointer group shadow-lg"
                        >
                            <img 
                                src={video.thumbnail} 
                                alt={video.title} 
                                className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500" 
                                referrerPolicy="no-referrer"
                                loading="lazy"
                            />
                            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors" />
                            <div className="absolute top-2 right-2 bg-black/60 px-2 py-0.5 rounded text-[10px] font-bold text-white">
                                {video.duration}
                            </div>
                            <div className="absolute bottom-2 left-2 right-2">
                                <p className="text-white text-xs font-semibold truncate drop-shadow-md">{video.title}</p>
                            </div>
                            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="currentColor" viewBox="0 0 24 24">
                                    <path d="M8 5v14l11-7z" />
                                </svg>
                            </div>
                        </div>
                    ))}
                </div>
            )}
            {selectedVideo && <VideoPlayerModal video={selectedVideo} onClose={() => setSelectedVideo(null)} />}
        </div>
    );
};

export default ShortsGallery;
