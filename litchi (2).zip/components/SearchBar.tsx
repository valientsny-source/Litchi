
import React, { useState, useRef, useEffect } from 'react';
import type { Creator } from '../types';
import { useApp } from '../contexts/AppContext';

interface SearchBarProps {
    onResultClick: (creatorId: string) => void;
}

const SearchBar: React.FC<SearchBarProps> = ({ onResultClick }) => {
    const { creators, getStreamByCreatorId } = useApp();
    const [query, setQuery] = useState('');
    const [isOpen, setIsOpen] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);

    const results = query.trim() === '' 
        ? [] 
        : creators.filter(c => 
            c.name.toLowerCase().includes(query.toLowerCase())
        ).slice(0, 5);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleSelect = (creatorId: string) => {
        onResultClick(creatorId);
        setQuery('');
        setIsOpen(false);
    };

    return (
        <div className="relative flex-1 max-w-xl mx-2 md:mx-4" ref={dropdownRef}>
            <div className="relative group">
                <input 
                    type="text" 
                    value={query}
                    onChange={(e) => {
                        setQuery(e.target.value);
                        setIsOpen(true);
                    }}
                    onFocus={() => setIsOpen(true)}
                    placeholder="Find creators..." 
                    aria-label="Search for creators and streams"
                    className="w-full bg-gray-900 border border-gray-800 rounded-2xl py-2 pl-8 pr-4 md:px-10 text-xs md:text-sm focus:ring-2 focus:ring-purple-500/50 outline-none transition-all focus:border-purple-500/50"
                />
                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 md:h-4 md:w-4 absolute left-3 md:left-4 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-purple-400 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
            </div>

            {isOpen && results.length > 0 && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-gray-900 border border-gray-800 rounded-2xl shadow-2xl overflow-hidden z-[110] animate-slide-up">
                    <div className="p-2">
                        <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest px-3 py-2">Creators & Streams</p>
                        {results.map(creator => {
                            const stream = getStreamByCreatorId(creator.id);
                            return (
                                <button
                                    key={creator.id}
                                    onClick={() => handleSelect(creator.id)}
                                    className="w-full flex items-center space-x-3 p-3 hover:bg-white/5 transition-colors rounded-xl text-left group"
                                >
                                    <div className="relative">
                                        <img 
                                            src={creator.avatar} 
                                            alt={creator.name} 
                                            className="w-10 h-10 rounded-xl object-cover border border-gray-800"
                                            referrerPolicy="no-referrer"
                                        />
                                        {stream?.isLive && (
                                            <span className="absolute -top-1 -right-1 flex h-3 w-3">
                                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                                                <span className="relative inline-flex rounded-full h-3 w-3 bg-red-600 border-2 border-gray-900"></span>
                                            </span>
                                        )}
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <p className="text-sm font-black text-white truncate group-hover:text-purple-400 transition-colors">{creator.name}</p>
                                        <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wider">
                                            {stream?.isLive ? 'Live Now' : `${creator.followers.toLocaleString()} Followers`}
                                        </p>
                                    </div>
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-gray-600 group-hover:text-white transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                    </svg>
                                </button>
                            );
                        })}
                    </div>
                </div>
            )}
        </div>
    );
};

export default SearchBar;
