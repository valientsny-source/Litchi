
import React, { useMemo } from 'react';
import { useApp } from '../contexts/AppContext';
import CreatorCard from '../components/CreatorCard';
import type { Creator } from '../types';
import { HtmlInjector } from '../App';

interface HomeViewProps {
    onTuneIn: (creatorId: string) => void;
    onVisitChannel: (creatorId: string) => void;
    onLoginClick: () => void;
    onSignUpClick: () => void;
}

const HomeView: React.FC<HomeViewProps> = ({ onTuneIn, onVisitChannel, onLoginClick, onSignUpClick }) => {
    const { creators, currentUser, getStreamByCreatorId, platformSettings } = useApp();
    
    const sortedCreators = useMemo(() => {
        return creators
            .filter(c => c.id !== currentUser?.id)
            .sort((a, b) => {
                const streamA = getStreamByCreatorId(a.id);
                const streamB = getStreamByCreatorId(b.id);
                if (streamA?.isLive && !streamB?.isLive) return -1;
                if (!streamA?.isLive && streamB?.isLive) return 1;
                return b.followers - a.followers;
            });
    }, [creators, currentUser, getStreamByCreatorId]);

    const liveNow = useMemo(() => {
        return sortedCreators.filter(c => {
            const s = getStreamByCreatorId(c.id);
            return s?.isLive || s?.endedAt;
        });
    }, [sortedCreators, getStreamByCreatorId]);

    const suggested = useMemo(() => {
        return sortedCreators.filter(c => {
            const s = getStreamByCreatorId(c.id);
            return !s?.isLive && !s?.endedAt;
        });
    }, [sortedCreators, getStreamByCreatorId]);

    return (
        <div className="pb-20">
            {/* Landing Page Content (Only for Guests) */}
            {!currentUser && (
                <div className="relative overflow-hidden bg-gray-950">
                    {/* Hero Background Elements */}
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[600px] bg-purple-600/5 blur-[120px] pointer-events-none rounded-full"></div>
                    <div className="absolute top-40 right-10 w-64 h-64 bg-blue-600/5 blur-[100px] pointer-events-none rounded-full"></div>

                    {/* Hero Section */}
                    <section className="relative pt-20 pb-16 px-6 md:px-12 max-w-[1400px] mx-auto text-center animate-slide-up">
                        <div className="inline-flex items-center space-x-2 px-3 py-1 bg-white/5 border border-white/10 rounded-full mb-8">
                            <span className="relative flex h-2 w-2">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                            </span>
                            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Join 50k+ creators online now</span>
                        </div>
                        
                        <h1 className="text-5xl md:text-8xl font-black text-white tracking-tighter leading-tight mb-8">
                            Experience the <br />
                            <span className="litchi-gradient-text">Future of Live</span>
                        </h1>
                        <p className="text-gray-400 text-lg md:text-2xl font-medium max-w-2xl mx-auto leading-relaxed mb-12">
                            Litchi is the world's most vibrant platform for gamers, techies, and digital nomads. Broadcast with zero latency and build your empire.
                        </p>
                        
                        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                            <button 
                                onClick={onSignUpClick}
                                className="w-full sm:w-auto px-12 py-5 bg-purple-600 hover:bg-purple-700 text-white font-black rounded-[2rem] transition-all shadow-2xl shadow-purple-500/40 hover:scale-105 active:scale-95 text-lg uppercase tracking-widest"
                            >
                                Start Streaming
                            </button>
                            <button 
                                onClick={onLoginClick}
                                className="w-full sm:w-auto px-12 py-5 bg-white/5 hover:bg-white/10 text-white font-black rounded-[2rem] transition-all border border-white/10 text-lg uppercase tracking-widest"
                            >
                                Browse Feed
                            </button>
                        </div>
                    </section>

                    {/* Features Grid */}
                    <section className="px-6 md:px-12 max-w-[1400px] mx-auto grid grid-cols-1 md:grid-cols-2 gap-6 py-12 mb-12">
                        <div className="bg-gray-900/40 p-8 rounded-[2.5rem] border border-gray-800 hover:border-purple-500/30 transition-all group">
                            <div className="w-14 h-14 bg-red-500/10 rounded-2xl flex items-center justify-center text-3xl mb-6 group-hover:scale-110 transition-transform">🎥</div>
                            <h3 className="text-xl font-black mb-3">Instant Live</h3>
                            <p className="text-gray-500 text-sm leading-relaxed">Broadcast your camera or mobile feed with high-fidelity 4K support and zero lag.</p>
                        </div>
                        <div className="bg-gray-900/40 p-8 rounded-[2.5rem] border border-gray-800 hover:border-blue-500/30 transition-all group">
                            <div className="w-14 h-14 bg-blue-500/10 rounded-2xl flex items-center justify-center text-3xl mb-6 group-hover:scale-110 transition-transform">💻</div>
                            <h3 className="text-xl font-black mb-3">Pro Screen Share</h3>
                            <p className="text-gray-500 text-sm leading-relaxed">Share your gameplay, tutorials, or meetings with studio-quality audio merging.</p>
                        </div>
                    </section>
                </div>
            )}

            <div className={`p-6 md:p-8 lg:p-12 max-w-[1600px] mx-auto space-y-12 ${!currentUser ? 'bg-gray-950 border-t border-gray-900' : ''}`}>
                {/* Live Section */}
                {liveNow.length > 0 && (
                    <section className="space-y-8">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4">
                                <div className="flex h-3 w-3 relative">
                                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                                    <span className="relative inline-flex rounded-full h-3 w-3 bg-red-600"></span>
                                </div>
                                <h2 className="text-2xl font-black text-white tracking-tight uppercase">Live & Recent</h2>
                            </div>
                            <div className="flex items-center space-x-2 text-[10px] bg-gray-900 border border-gray-800 px-3 py-1.5 rounded-full font-black text-gray-500 uppercase tracking-widest">
                                <span>Global Live Count:</span>
                                <span className="text-white">{liveNow.length}</span>
                            </div>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                            {liveNow.map((creator: Creator) => (
                                <div key={creator.id} className="animate-fade-in-left">
                                    <CreatorCard 
                                        creator={creator} 
                                        onTuneIn={onTuneIn} 
                                        onVisitChannel={onVisitChannel} 
                                    />
                                </div>
                            ))}
                        </div>
                    </section>
                )}

                {/* Monetization Feed Placement */}
                {platformSettings.monetization?.feedCode && (
                    <section className="w-full my-8">
                        <HtmlInjector html={platformSettings.monetization.feedCode} className="w-full flex justify-center" />
                    </section>
                )}

                {/* Suggested Section */}
                <section className="space-y-8">
                    <div className="flex items-center justify-between border-b border-gray-900 pb-4">
                        <div className="flex items-center space-x-3">
                            <h2 className="text-2xl font-black text-white tracking-tight uppercase">Top Creators</h2>
                        </div>
                        <button className="text-purple-400 text-xs font-black uppercase tracking-[0.2em] hover:text-purple-300 transition-colors">See the full leaderboard</button>
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                        {suggested.map((creator: Creator) => (
                            <div key={creator.id} className="animate-slide-up" style={{ animationDelay: '0.1s' }}>
                                <CreatorCard 
                                    creator={creator} 
                                    onTuneIn={onTuneIn} 
                                    onVisitChannel={onVisitChannel} 
                                />
                            </div>
                        ))}
                    </div>
                    
                    {sortedCreators.length === 0 && (
                        <div className="text-center py-32 bg-gray-900/20 rounded-[3rem] border-2 border-dashed border-gray-900 flex flex-col items-center justify-center space-y-6">
                            <div className="w-24 h-24 bg-gray-900 rounded-full flex items-center justify-center text-5xl shadow-inner border border-gray-800 animate-bounce">🌍</div>
                            <div className="space-y-2">
                                <p className="text-white text-2xl font-black tracking-tight">The world is quiet...</p>
                                <p className="text-gray-500 max-w-sm mx-auto font-medium">Be the pioneer that breaks the silence. Start the first live stream on Litchi today!</p>
                            </div>
                            <button 
                                onClick={() => currentUser ? (window.location.pathname = '/profile') : onSignUpClick()}
                                className="px-10 py-4 bg-purple-600/10 text-purple-400 font-black rounded-2xl border border-purple-500/20 hover:bg-purple-600 hover:text-white transition-all uppercase tracking-widest text-xs"
                            >
                                Start Global Broadcast
                            </button>
                        </div>
                    )}
                </section>
            </div>

            {/* Platform Footer */}
            <footer className="mt-20 border-t border-gray-900 pt-16 pb-32 px-6 md:px-12 max-w-[1400px] mx-auto">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-12 mb-16">
                    <div className="col-span-2">
                        <div className="litchi-gradient-text text-4xl font-black mb-6">litchi</div>
                        <p className="text-gray-500 text-sm max-w-xs leading-relaxed font-medium">
                            Empowering the next generation of digital performers through vibrant technology and community first design.
                        </p>
                    </div>
                    <div>
                        <h4 className="text-white font-black uppercase tracking-widest text-xs mb-6">Explore</h4>
                        <ul className="space-y-4 text-gray-500 text-sm font-bold">
                            <li className="hover:text-purple-400 cursor-pointer transition-colors">Creators</li>
                            <li className="hover:text-purple-400 cursor-pointer transition-colors">Trending</li>
                        </ul>
                    </div>
                    <div>
                        <h4 className="text-white font-black uppercase tracking-widest text-xs mb-6">Legal</h4>
                        <ul className="space-y-4 text-gray-500 text-sm font-bold">
                            <li className="hover:text-purple-400 cursor-pointer transition-colors">Privacy</li>
                            <li className="hover:text-purple-400 cursor-pointer transition-colors">Terms</li>
                            <li className="hover:text-purple-400 cursor-pointer transition-colors">DMCA</li>
                        </ul>
                    </div>
                </div>
                <div className="text-center pt-8 border-t border-gray-900">
                    <p className="text-gray-600 text-[10px] font-black uppercase tracking-[0.3em]">© 2025 Litchi Platform. All rights reserved.</p>
                </div>
            </footer>
        </div>
    );
};

export default HomeView;
