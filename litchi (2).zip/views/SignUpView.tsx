import React, { useState } from 'react';
import { auth, db } from '../firebase';
import { 
    createUserWithEmailAndPassword, 
    signInWithPopup, 
    GoogleAuthProvider, 
    GithubAuthProvider,
    updateProfile
} from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { useApp } from '../contexts/AppContext';
import { handleFirestoreError, OperationType } from '../src/lib/firestoreUtils';

interface SignUpViewProps {
    onSignUp: (name: string) => void;
    onBack: () => void;
    onLoginClick: () => void;
}

const SignUpView: React.FC<SignUpViewProps> = ({ onSignUp, onBack, onLoginClick }) => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    
    const { login, platformSettings } = useApp();

    const handleFirebaseSignUp = async (userCredential: any, displayName: string) => {
        const user = userCredential.user;
        
        if (platformSettings.disableSignups && user.email !== 'maphangabowe@gmail.com') {
            setError('New registrations are currently disabled by the administrator.');
            await user.delete();
            return;
        }

        // Create user document in Firestore
        const userRef = doc(db, 'users', user.uid);
        const path = `users/${user.uid}`;
        let userSnap;
        try {
            userSnap = await getDoc(userRef);
        } catch (error) {
            handleFirestoreError(error, OperationType.GET, path);
        }
        
        if (userSnap && !userSnap.exists()) {
            try {
                await setDoc(userRef, {
                    id: user.uid,
                    name: displayName || user.displayName || 'New Creator',
                    avatar: user.photoURL || `https://i.pravatar.cc/150?u=${user.uid}`,
                    followers: 0,
                    coins: 100,
                    lifetimeCoins: 0,
                    streamCount: 0,
                    links: [],
                    videos: [],
                    isAdmin: user.email === 'maphangabowe@gmail.com'
                });
            } catch (error) {
                handleFirestoreError(error, OperationType.WRITE, path);
            }
        }
        
        // Update local state
        onSignUp(displayName || user.displayName || 'New Creator');
    };

    const handleError = (err: any, defaultMessage: string) => {
        console.error(err);
        if (err.code === 'auth/operation-not-allowed') {
            setError('This sign-in method is disabled. Please enable it in the Firebase Console under Authentication > Sign-in method.');
        } else if (err.code === 'auth/popup-closed-by-user') {
            // User closed the popup, don't show an error message
            setError('');
        } else if (err.code === 'auth/invalid-credential') {
            setError('Invalid email or password. Please check your credentials and try again.');
        } else {
            setError(err.message || defaultMessage);
        }
    };

    const handleEmailSignUp = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!name.trim() || !email.trim() || !password.trim()) {
            setError('Please fill in all fields');
            return;
        }
        
        setLoading(true);
        setError('');
        
        try {
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            await updateProfile(userCredential.user, { displayName: name });
            await handleFirebaseSignUp(userCredential, name);
        } catch (err: any) {
            handleError(err, 'Failed to sign up');
        } finally {
            setLoading(false);
        }
    };

    const handleGoogleSignUp = async () => {
        setLoading(true);
        setError('');
        try {
            const provider = new GoogleAuthProvider();
            const userCredential = await signInWithPopup(auth, provider);
            await handleFirebaseSignUp(userCredential, userCredential.user.displayName || 'Google User');
        } catch (err: any) {
            handleError(err, 'Failed to sign up with Google');
        } finally {
            setLoading(false);
        }
    };

    const handleGithubSignUp = async () => {
        setLoading(true);
        setError('');
        try {
            const provider = new GithubAuthProvider();
            const userCredential = await signInWithPopup(auth, provider);
            await handleFirebaseSignUp(userCredential, userCredential.user.displayName || 'GitHub User');
        } catch (err: any) {
            handleError(err, 'Failed to sign up with GitHub');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="h-screen w-screen flex flex-col justify-center items-center p-4 bg-gray-900 text-white overflow-y-auto">
             <button onClick={onBack} className="absolute top-6 left-6 text-gray-400 hover:text-white transition-colors flex items-center space-x-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
                <span>Back</span>
            </button>
             <div className="w-full max-w-sm text-center py-8">
                <h1 className="text-4xl font-bold mb-4">Create Your Account</h1>
                <p className="text-gray-400 mb-6">Choose a sign up method to join litchi.</p>
                
                {platformSettings.disableSignups && (
                    <div className="bg-amber-500/10 border border-amber-500/50 text-amber-500 p-3 rounded-lg mb-6 text-sm font-bold flex items-center justify-center space-x-2">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                        </svg>
                        <span>Registrations are temporarily closed</span>
                    </div>
                )}

                {error && (
                    <div className="bg-red-500/10 border border-red-500/50 text-red-500 p-3 rounded-lg mb-6 text-sm">
                        {error}
                    </div>
                )}

                <div className="flex flex-col space-y-3 mb-6">
                    <button
                        onClick={handleGoogleSignUp}
                        disabled={loading}
                        className="w-full flex items-center justify-center space-x-2 bg-white text-gray-900 font-bold py-3 rounded-lg hover:bg-gray-100 transition-colors disabled:opacity-50"
                    >
                        <svg className="w-5 h-5" viewBox="0 0 24 24">
                            <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                        </svg>
                        <span>Sign up with Google</span>
                    </button>
                    
                    <button
                        onClick={handleGithubSignUp}
                        disabled={loading}
                        className="w-full flex items-center justify-center space-x-2 bg-[#24292e] text-white font-bold py-3 rounded-lg hover:bg-[#2f363d] transition-colors disabled:opacity-50"
                    >
                        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                            <path fillRule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" clipRule="evenodd" />
                        </svg>
                        <span>Sign up with GitHub</span>
                    </button>
                </div>

                <div className="flex items-center mb-6">
                    <div className="flex-1 border-t border-gray-700"></div>
                    <span className="px-3 text-gray-500 text-sm">or sign up with email</span>
                    <div className="flex-1 border-t border-gray-700"></div>
                </div>

                <form onSubmit={handleEmailSignUp} className="text-left space-y-4">
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-1">Creator Name</label>
                        <input
                            id="name"
                            type="text"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            placeholder="e.g., CaptainCode"
                            className="w-full p-3 bg-gray-800 border border-gray-700 rounded-md text-white focus:ring-2 focus:ring-purple-500 outline-none"
                        />
                    </div>
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-1">Email Address</label>
                        <input
                            id="email"
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="you@example.com"
                            className="w-full p-3 bg-gray-800 border border-gray-700 rounded-md text-white focus:ring-2 focus:ring-purple-500 outline-none"
                        />
                    </div>
                    <div>
                        <label htmlFor="password" className="block text-sm font-medium text-gray-300 mb-1">Password</label>
                        <input
                            id="password"
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="••••••••"
                            className="w-full p-3 bg-gray-800 border border-gray-700 rounded-md text-white focus:ring-2 focus:ring-purple-500 outline-none"
                        />
                    </div>
                    
                    <button
                        type="submit"
                        disabled={loading || !name.trim() || !email.trim() || !password.trim()}
                        className="w-full mt-2 bg-purple-600 text-white font-bold py-3 rounded-lg text-lg hover:bg-purple-700 transition-all disabled:bg-purple-800 disabled:cursor-not-allowed transform hover:scale-105 active:scale-95"
                    >
                        {loading ? 'Creating Account...' : 'Sign Up & Go Live'}
                    </button>
                </form>

                <div className="mt-8 text-center">
                    <p className="text-gray-400 text-sm">
                        Already have an account?{' '}
                        <button onClick={onLoginClick} className="text-purple-400 hover:text-purple-300 font-bold hover:underline">
                            Log in
                        </button>
                    </p>
                </div>
            </div>
        </div>
    );
};

export default SignUpView;