
import React, { useEffect, useRef, useState, useCallback } from 'react';
import { useMediaStream, StreamSource } from '../hooks/useMediaStream';
import { useApp } from '../contexts/AppContext';
import { GoogleGenAI } from "@google/genai";
import type { Gift, GiftEvent } from '../types';

const GIFTS: Gift[] = [
    { id: 'rose', name: 'Rose', icon: '🌹', cost: 1 },
    { id: 'diamond', name: 'Diamond', icon: '💎', cost: 10 },
    { id: 'rocket', name: 'Rocket', icon: '🚀', cost: 100 },
    { id: 'castle', name: 'Castle', icon: '🏰', cost: 1000 },
];

const GiftAnimation: React.FC<{ gift: Gift }> = ({ gift }) => {
    const randomX = useRef(Math.random() * 80 + 10);
    const scale = gift.cost >= 1000 ? 'text-8xl' : gift.cost >= 100 ? 'text-6xl' : 'text-4xl';

    return (
        <div 
            className="absolute bottom-0 animate-float-up pointer-events-none"
            style={{ left: `${randomX.current}%`, transform: 'translateX(-50%)' }}
        >
            <div className="flex flex-col items-center">
                <span className={scale}>{gift.icon}</span>
                {gift.cost >= 100 && <span className="text-xs bg-yellow-400 text-black px-1 font-black rounded uppercase">Big Gift!</span>}
            </div>
        </div>
    );
};

const GiftPanel: React.FC<{ onSendGift: (gift: Gift) => void; userCoins: number; onClose: () => void }> = ({ onSendGift, userCoins, onClose }) => {
    return (
        <div className="fixed inset-0 bg-black/70 flex flex-col justify-end z-50" onClick={onClose}>
            <div 
                className="bg-gray-800 rounded-t-3xl p-6 shadow-2xl w-full animate-slide-up border-t border-purple-500/30"
                onClick={e => e.stopPropagation()}
            >
                <div className="flex justify-between items-center mb-6 px-2">
                    <h3 className="text-xl font-extrabold text-white">Send a Gift</h3>
                    <div className="flex items-center space-x-2 bg-gray-900 px-4 py-1.5 rounded-full border border-gray-700">
                         <span className="text-yellow-400">💎</span>
                         <span className="font-black text-white">{userCoins.toLocaleString()}</span>
                    </div>
                </div>
                <div className="grid grid-cols-4 gap-4 py-4">
                    {GIFTS.map(gift => {
                        const canAfford = userCoins >= gift.cost;
                        return (
                             <button
                                key={gift.id}
                                disabled={!canAfford}
                                onClick={() => onSendGift(gift)}
                                className={`flex flex-col items-center p-3 rounded-2xl transition-all border ${
                                    canAfford 
                                    ? 'bg-gray-700/50 hover:bg-purple-600/30 hover:border-purple-500 border-transparent active:scale-90' 
                                    : 'bg-gray-900/50 opacity-40 cursor-not-allowed border-transparent'
                                }`}
                            >
                                <span className="text-4xl md:text-5xl mb-2">{gift.icon}</span>
                                <span className="text-xs font-bold text-gray-300 truncate w-full text-center">{gift.name}</span>
                                <div className="flex items-center space-x-1 text-[11px] mt-1 font-black text-yellow-500">
                                    <span>{gift.cost.toLocaleString()}</span>
                                    <span>💎</span>
                                </div>
                            </button>
                        );
                    })}
                </div>
            </div>
        </div>
    );
};


interface LiveStreamViewProps {
    creatorId: string;
    onEndStream: (creatorId: string) => void;
    source?: StreamSource;
}

const CountdownOverlay: React.FC<{ count: number | string }> = ({ count }) => (
    <div className="absolute inset-0 z-[60] flex items-center justify-center bg-gray-900/60 backdrop-blur-md">
        <div 
            key={count} 
            className="text-8xl md:text-9xl font-black text-white animate-countdown-pop drop-shadow-[0_0_30px_rgba(168,85,247,0.8)]"
        >
            {count}
        </div>
    </div>
);

const AI_BOT_NAME = "LitchiBot AI";

const LiveStreamView: React.FC<LiveStreamViewProps> = ({ creatorId, onEndStream, source = 'camera' }) => {
    const handleAutoEnd = useCallback(() => {
        onEndStream(creatorId);
    }, [onEndStream, creatorId]);

    const { stream, error, isLoading } = useMediaStream(source as StreamSource, handleAutoEnd);
    const videoRef = useRef<HTMLVideoElement>(null);
    const chatFeedRef = useRef<HTMLDivElement>(null);
    const { creators, currentUser, streamCoinTotals, streamGiftEvents, sendGift } = useApp();
    const [isGiftPanelOpen, setIsGiftPanelOpen] = useState(false);
    
    // AI Chat Bot logic
    const [aiComments, setAiComments] = useState<{id: string, text: string}[]>([]);
    
    // Countdown state
    const [countdown, setCountdown] = useState<number | string | null>(null);
    const [isReady, setIsReady] = useState(false);

    const creator = creators.find(c => c.id === creatorId);
    const isCurrentUserStreaming = currentUser?.id === creatorId;
    
    const streamTotal = streamCoinTotals[creatorId] || 0;
    const giftsForStream = streamGiftEvents[creatorId] || [];

    const [highlightCoin, setHighlightCoin] = useState(false);
    const prevStreamTotal = useRef(streamTotal);

    useEffect(() => {
        if (streamTotal > prevStreamTotal.current) {
            setHighlightCoin(true);
            const timer = setTimeout(() => setHighlightCoin(false), 500);
            return () => clearTimeout(timer);
        }
    }, [streamTotal]);

    useEffect(() => {
        prevStreamTotal.current = streamTotal;
    });

    useEffect(() => {
        if (videoRef.current && stream) {
            videoRef.current.srcObject = stream;
        }
    }, [stream]);

    // Handle Countdown
    useEffect(() => {
        if (isCurrentUserStreaming && stream && !isReady && countdown === null) {
            setCountdown(3);
        } else if (!isCurrentUserStreaming) {
            setIsReady(true);
        }
    }, [isCurrentUserStreaming, stream, isReady, countdown]);

    useEffect(() => {
        if (countdown !== null && typeof countdown === 'number') {
            if (countdown > 0) {
                const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
                return () => clearTimeout(timer);
            } else if (countdown === 0) {
                setCountdown('LITCHI!');
                const timer = setTimeout(() => {
                    setCountdown(null);
                    setIsReady(true);
                }, 1000);
                return () => clearTimeout(timer);
            }
        }
    }, [countdown]);

    // Gemini AI Chat Moderator
    useEffect(() => {
        if (!isReady || !creator) return;

        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        
        const triggerAiComment = async () => {
            try {
                const response = await ai.models.generateContent({
                    model: 'gemini-3-flash-preview',
                    contents: `You are an AI chat moderator for a live stream by ${creator.name}. 
                    Write a short, engaging, 1-sentence comment to the chat that is supportive, funny, or hype. 
                    Keep it informal and use emojis. Output ONLY the comment text.`,
                    config: { temperature: 0.9 }
                });
                const comment = response.text?.trim();
                if (comment) {
                    setAiComments(prev => [...prev.slice(-10), { id: `ai-${Date.now()}`, text: comment }]);
                }
            } catch (e) {
                console.debug("AI moderator failed to speak:", e);
            }
        };

        // Initial comment
        triggerAiComment();

        const interval = setInterval(triggerAiComment, 25000); // Comment every 25s
        return () => clearInterval(interval);
    }, [isReady, creator]);

    useEffect(() => {
        if (chatFeedRef.current) {
            chatFeedRef.current.scrollTop = chatFeedRef.current.scrollHeight;
        }
    }, [giftsForStream, aiComments]);

    const handleSendGift = (gift: Gift) => {
        const success = sendGift(creatorId, gift);
        if (!success) {
            alert("You don't have enough coins! Go to Profile to Top Up. 💎");
        }
    };
    
    const renderVideoContent = () => {
        if (isLoading) return <div className="flex flex-col items-center"><div className="w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mb-4"></div><p className="text-xl animate-pulse">Starting {source}...</p></div>;
        if (error) return <div className="text-center p-8 bg-gray-800 rounded-2xl border border-red-500/30"><p className="text-xl text-red-500 mb-4">{error}</p><button onClick={() => window.location.reload()} className="bg-white/10 px-6 py-2 rounded-full text-sm font-bold hover:bg-white/20 transition-colors">Retry Connection</button></div>;
        if (stream) {
            return (
                <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted={isCurrentUserStreaming}
                    className="w-full h-full object-cover"
                />
            );
        }
        return <div className="w-full h-full bg-gray-800 flex items-center justify-center"><p>Stream Offline</p></div>;
    };

    if (!creator) {
        return <div className="h-screen w-screen flex items-center justify-center bg-gray-900">Creator not found.</div>
    }

    return (
        <div className="flex flex-col md:flex-row h-screen bg-black text-white font-sans overflow-hidden">
            {/* Main Content (Video + Info) */}
            <main className="flex-grow flex flex-col h-full relative overflow-hidden">
                {/* Countdown Overlay */}
                {countdown !== null && <CountdownOverlay count={countdown} />}

                {/* Video Player */}
                <div className={`relative w-full flex-grow bg-black flex items-center justify-center overflow-hidden shadow-inner ${source === 'screen' ? 'bg-gray-950' : 'bg-black'}`}>
                    {renderVideoContent()}
                    
                    {/* Source Indicator / Screen Share UI */}
                    {source === 'screen' && isReady && (
                        <>
                            <div className="absolute top-4 left-20 bg-blue-600 text-white text-[10px] font-black px-3 py-1 rounded-full z-10 flex items-center border border-blue-400 shadow-[0_0_15px_rgba(37,99,235,0.4)]">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                                </svg>
                                SHARING SCREEN + MIC
                            </div>
                            {/* Decorative technical corner elements for screen sharing */}
                            <div className="absolute top-0 left-0 w-16 h-16 border-t-2 border-l-2 border-blue-500/40 pointer-events-none"></div>
                            <div className="absolute top-0 right-0 w-16 h-16 border-t-2 border-r-2 border-blue-500/40 pointer-events-none"></div>
                            <div className="absolute bottom-0 left-0 w-16 h-16 border-b-2 border-l-2 border-blue-500/40 pointer-events-none"></div>
                            <div className="absolute bottom-0 right-0 w-16 h-16 border-b-2 border-r-2 border-blue-500/40 pointer-events-none"></div>
                        </>
                    )}

                    {/* Gift Animation Container */}
                    <div className="absolute inset-0 pointer-events-none z-40 overflow-hidden">
                        {giftsForStream.map(event => (
                            <GiftAnimation key={event.id} gift={event.gift} />
                        ))}
                    </div>

                    {/* Live Badge */}
                    {isReady && (
                        <div className="absolute top-4 left-4 bg-red-600 text-white text-xs font-black px-3 py-1 rounded flex items-center z-10 border border-white/20 shadow-lg">
                            <span className="w-2 h-2 bg-white rounded-full mr-2 animate-ping"></span>
                            LIVE
                        </div>
                    )}
                    
                    {/* Viewer Counter Mock */}
                    {isReady && (
                        <div className="absolute top-4 right-4 bg-black/40 backdrop-blur px-3 py-1 rounded text-xs font-bold z-10 border border-white/10 flex items-center space-x-2">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-red-400" fill="currentColor" viewBox="0 0 24 24"><path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/></svg>
                            <span>{Math.floor(Math.random() * 50) + 120}</span>
                        </div>
                    )}
                </div>
                
                {/* Stream Info & Actions */}
                <section className="p-4 border-b md:border-b-0 md:border-t border-gray-800 bg-gray-950 shrink-0 z-20">
                   <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
                        <div className="flex items-center w-full sm:w-auto">
                            <div className="relative">
                                <img src={creator.avatar} alt={creator.name} className="w-14 h-14 rounded-full border-2 border-purple-500 shadow-lg shadow-purple-500/20 object-cover" referrerPolicy="no-referrer" loading="lazy" />
                                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-gray-950 rounded-full"></div>
                            </div>
                            <div className="ml-4">
                                <p className="font-black text-xl text-white">{creator.name}</p>
                                <p className="text-gray-500 text-xs font-bold uppercase tracking-widest">{creator.followers.toLocaleString()} followers</p>
                            </div>
                        </div>

                        <div className="flex items-center space-x-6 w-full sm:w-auto justify-between sm:justify-end">
                            {isCurrentUserStreaming ? (
                                <>
                                    <div className={`text-center transition-transform duration-300 ${highlightCoin ? 'scale-125' : ''}`}>
                                        <p className="font-black text-2xl text-yellow-400 flex items-center justify-center">
                                            <span className="mr-2 text-xl">💎</span>
                                            {streamTotal.toLocaleString()}
                                        </p>
                                        <p className="text-[10px] text-gray-500 uppercase font-black tracking-tighter">Earnings</p>
                                    </div>
                                    <button
                                        onClick={() => onEndStream(creatorId)}
                                        className="bg-red-600 text-white font-black py-3 px-8 rounded-2xl text-lg hover:bg-red-700 transition-all transform hover:scale-105 active:scale-95 shadow-xl shadow-red-500/20 border-b-4 border-red-800"
                                    >
                                        End Stream
                                    </button>
                                </>
                            ) : (
                                <>
                                    <div className="text-center">
                                        <p className="font-black text-lg text-yellow-400 flex items-center">
                                            <span className="mr-1">💎</span>
                                            {currentUser?.coins.toLocaleString()}
                                        </p>
                                        <p className="text-[10px] text-gray-500 uppercase font-black tracking-tighter">Balance</p>
                                    </div>
                                    <button
                                        onClick={() => setIsGiftPanelOpen(true)}
                                        className="bg-purple-600 text-white font-black py-3 px-8 rounded-2xl text-lg hover:bg-purple-700 transition-all transform hover:scale-105 active:scale-95 shadow-xl shadow-purple-500/20 border-b-4 border-purple-800 flex items-center"
                                    >
                                        <span className="mr-2 text-2xl">🎁</span>
                                        <span>GIFT</span>
                                    </button>
                                </>
                            )}
                        </div>
                   </div>
                </section>
            </main>

            {/* Side Panel (Chat/Events) */}
            <aside className="w-full h-[40vh] md:h-full md:w-80 lg:w-96 bg-gray-900 flex flex-col border-t md:border-t-0 md:border-l border-gray-800 shrink-0 z-10 shadow-2xl">
                <header className="p-4 border-b border-gray-800 flex items-center justify-between">
                    <h2 className="font-black text-xs uppercase tracking-[0.2em] text-gray-400">Activity Feed</h2>
                    <div className="bg-purple-600/10 text-purple-400 text-[10px] px-2 py-0.5 rounded font-black border border-purple-500/20">AI MOD ON</div>
                </header>
                <div ref={chatFeedRef} className="flex-grow p-4 overflow-y-auto space-y-4 no-scrollbar">
                    {/* Welcome Message */}
                    <div className="bg-white/5 p-3 rounded-xl border border-white/10">
                        <p className="text-gray-400 text-xs leading-relaxed italic">
                            Welcome to the stream! Be nice in the chat. Send gifts to support the creator!
                        </p>
                    </div>

                    {!isReady && isCurrentUserStreaming ? (
                        <div className="flex flex-col items-center justify-center h-full text-gray-400 animate-pulse text-center space-y-2">
                            <div className="text-4xl">🎬</div>
                            <p className="font-bold">Broadcasting starting in {countdown === 'LITCHI!' ? '1...' : countdown + '...'}</p>
                        </div>
                    ) : (
                        <>
                            {/* Combined Feed (Gifts + AI Comments) */}
                            {[...giftsForStream, ...aiComments.map(c => ({...c, isAi: true}))]
                                .sort((a: any, b: any) => (a.timestamp || 0) - (b.timestamp || 0))
                                .map((item: any) => (
                                    <div key={item.id} className={`p-3 rounded-2xl text-sm animate-fade-in-left transition-all border ${
                                        item.isAi 
                                        ? 'bg-blue-600/10 border-blue-500/20' 
                                        : 'bg-purple-600/10 border-purple-500/20'
                                    }`}>
                                        <div className="flex items-start space-x-3">
                                            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black shrink-0 ${
                                                item.isAi ? 'bg-blue-600 text-white' : 'bg-purple-600 text-white'
                                            }`}>
                                                {item.isAi ? '🤖' : (item.sender?.name?.charAt(0) || 'U')}
                                            </div>
                                            <div className="flex flex-col">
                                                <span className={`font-black text-[10px] uppercase tracking-wider mb-0.5 ${
                                                    item.isAi ? 'text-blue-400' : 'text-purple-400'
                                                }`}>
                                                    {item.isAi ? AI_BOT_NAME : item.sender.name}
                                                </span>
                                                <p className="text-gray-200">
                                                    {item.isAi ? item.text : (
                                                        <>
                                                            sent <span className="font-black text-yellow-400">{item.gift.name}</span> {item.gift.icon}
                                                        </>
                                                    )}
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                ))
                            }
                            {giftsForStream.length === 0 && aiComments.length === 0 && (
                                <div className="flex flex-col items-center justify-center py-20 text-gray-600 space-y-2">
                                    <div className="text-4xl opacity-20">💬</div>
                                    <p className="text-xs font-black uppercase tracking-widest opacity-40">Feed is waiting for hype...</p>
                                </div>
                            )}
                        </>
                    )}
                </div>
                
                {/* Chat Input Placeholder */}
                {!isCurrentUserStreaming && (
                    <div className="p-4 border-t border-gray-800">
                        <div className="bg-gray-800 rounded-xl p-3 text-gray-500 text-sm flex justify-between items-center cursor-not-allowed italic">
                            <span>Type to chat...</span>
                            <span className="text-xs opacity-50">Locked</span>
                        </div>
                    </div>
                )}
            </aside>
            
            {isGiftPanelOpen && currentUser && (
                <GiftPanel
                    onSendGift={handleSendGift}
                    userCoins={currentUser.coins}
                    onClose={() => setIsGiftPanelOpen(false)}
                />
            )}
        </div>
    );
};

export default LiveStreamView;
