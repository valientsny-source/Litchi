
import React, { useState, useRef } from 'react';
import { useApp } from '../contexts/AppContext';
import ShortsGallery from '../components/ShortsGallery';
import type { Creator } from '../types';

interface CreatorChannelViewProps {
    creatorId: string;
    onBack: () => void;
    onTuneIn: (creatorId: string) => void;
}

const CoffeeAnimation: React.FC<{ id: number }> = ({ id }) => {
    const randomX = useRef(Math.random() * 60 + 20);
    return (
        <div 
            className="absolute bottom-0 animate-float-up pointer-events-none z-50 text-4xl"
            style={{ left: `${randomX.current}%`, transform: 'translateX(-50%)' }}
        >
            ☕
        </div>
    );
};

const CreatorChannelView: React.FC<CreatorChannelViewProps> = ({ creatorId, onBack, onTuneIn }) => {
    const { creators, following, currentUser, toggleFollow, getStreamByCreatorId, supportCreator } = useApp();
    const [activeTab, setActiveTab] = useState<'shorts' | 'about'>('shorts');
    const [coffeeAnimations, setCoffeeAnimations] = useState<{ id: number }[]>([]);
    
    const creator = creators.find(c => c.id === creatorId);
    if (!creator) return <div className="p-8 text-center text-white">Creator not found</div>;

    const isFollowing = following.includes(creator.id);
    const stream = getStreamByCreatorId(creatorId);
    const isOwner = currentUser?.id === creator.id;

    const handleBuyCoffee = () => {
        if (isOwner) {
            alert("You can't buy yourself coffee! You're the barista here.");
            return;
        }

        const cost = 5;
        const success = supportCreator(creator.id, cost);
        
        if (success) {
            const newId = Date.now();
            setCoffeeAnimations(prev => [...prev, { id: newId }]);
            setTimeout(() => {
                setCoffeeAnimations(prev => prev.filter(anim => anim.id !== newId));
            }, 5000);
        } else {
            alert("You need at least 5 coins to buy a coffee! 💎");
        }
    };

    return (
        <div className="min-h-screen bg-gray-900 animate-fade-in-left relative overflow-hidden">
            {/* Coffee Animations Container */}
            <div className="absolute inset-0 pointer-events-none overflow-hidden">
                {coffeeAnimations.map(anim => (
                    <CoffeeAnimation key={anim.id} id={anim.id} />
                ))}
            </div>

            <header className="p-4 flex items-center space-x-4 sticky top-0 bg-gray-900/80 backdrop-blur-md z-10 border-b border-gray-800">
                <button onClick={onBack} className="p-2 text-gray-400 hover:text-white transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7 7-7" />
                    </svg>
                </button>
                <h1 className="text-xl font-bold truncate">{creator.name}'s Channel</h1>
            </header>

            <div className="p-6 max-w-4xl mx-auto">
                <div className="flex flex-col items-center mb-8">
                    <div className="relative">
                        <img className="w-24 h-24 rounded-full border-4 border-purple-500 shadow-xl" src={creator.avatar} alt={creator.name} referrerPolicy="no-referrer" loading="lazy" />
                        {stream?.isLive && (
                            <div className="absolute -bottom-1 -right-1 bg-red-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full animate-pulse border-2 border-gray-900">
                                LIVE
                            </div>
                        )}
                    </div>
                    <h2 className="text-2xl font-bold mt-4">{creator.name}</h2>
                    <p className="text-gray-400 text-sm">{creator.followers.toLocaleString()} followers</p>
                    
                    <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3 mt-6 w-full max-w-xs sm:max-w-none justify-center">
                        <button
                            onClick={() => toggleFollow(creator.id)}
                            className={`px-8 py-2.5 rounded-full font-bold transition-all ${isFollowing ? 'bg-gray-700 text-gray-300' : 'bg-purple-600 text-white hover:bg-purple-700 shadow-lg shadow-purple-500/20'}`}
                        >
                            {isFollowing ? 'Following' : 'Follow'}
                        </button>
                        
                        {stream?.isLive && (
                            <button
                                onClick={() => onTuneIn(creator.id)}
                                className="px-8 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-full font-bold shadow-lg shadow-red-500/20 transition-all"
                            >
                                Watch Live
                            </button>
                        )}
                    </div>
                </div>

                <div className="border-b border-gray-800 flex justify-center space-x-8 mb-6">
                    <button 
                        onClick={() => setActiveTab('shorts')}
                        className={`pb-3 text-sm font-bold transition-colors border-b-2 ${activeTab === 'shorts' ? 'border-purple-500 text-white' : 'border-transparent text-gray-500'}`}
                    >
                        Shorts ({creator.videos?.length || 0}/7)
                    </button>
                    <button 
                        onClick={() => setActiveTab('about')}
                        className={`pb-3 text-sm font-bold transition-colors border-b-2 ${activeTab === 'about' ? 'border-purple-500 text-white' : 'border-transparent text-gray-500'}`}
                    >
                        About
                    </button>
                </div>

                {activeTab === 'shorts' ? (
                    <ShortsGallery videos={creator.videos || []} />
                ) : (
                    <div className="space-y-6">
                        <div className="bg-gray-800/50 p-6 rounded-2xl border border-gray-700">
                            <h3 className="text-lg font-bold mb-4">Channel Links</h3>
                            {creator.links && creator.links.length > 0 ? (
                                <div className="space-y-3">
                                    {creator.links.map((link, idx) => (
                                        <a key={idx} href={link.url} target="_blank" rel="noopener" className="flex items-center p-3 bg-gray-700/50 rounded-xl hover:bg-gray-700 transition-colors">
                                            <span className="flex-1 font-semibold">{link.title}</span>
                                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                                            </svg>
                                        </a>
                                    ))}
                                </div>
                            ) : (
                                <p className="text-gray-500 italic">No links shared.</p>
                            )}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default CreatorChannelView;
