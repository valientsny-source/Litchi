
import React from 'react';
import { useApp } from '../contexts/AppContext';
import CreatorCard from '../components/CreatorCard';
import type { Creator } from '../types';
import { HtmlInjector } from '../App';

interface FollowingViewProps {
    onTuneIn: (creatorId: string) => void;
    onVisitChannel: (creatorId: string) => void;
}

const FollowingView: React.FC<FollowingViewProps> = ({ onTuneIn, onVisitChannel }) => {
    const { creators, following, platformSettings } = useApp();
    const followedCreators = creators.filter(c => following.includes(c.id));

    return (
        <div className="p-4 md:p-8 max-w-7xl mx-auto">
            <h1 className="text-3xl font-bold mb-6 text-white">Following</h1>
            
            {/* Monetization Feed Placement */}
            {platformSettings.monetization?.feedCode && (
                <section className="w-full mb-8">
                    <HtmlInjector html={platformSettings.monetization.feedCode} className="w-full flex justify-center" />
                </section>
            )}

            {followedCreators.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {followedCreators.map((creator: Creator) => (
                        <CreatorCard 
                            key={creator.id} 
                            creator={creator} 
                            onTuneIn={onTuneIn} 
                            onVisitChannel={onVisitChannel} 
                        />
                    ))}
                </div>
            ) : (
                <div className="text-center text-gray-400 mt-20">
                    <p className="text-lg">You're not following any creators yet.</p>
                    <p className="mt-2 text-sm">Go to the Home page to discover new creators and their shorts!</p>
                </div>
            )}
        </div>
    );
};

export default FollowingView;
