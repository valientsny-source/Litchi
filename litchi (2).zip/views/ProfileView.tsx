
import React, { useState, useEffect, useCallback } from 'react';
import { useApp } from '../contexts/AppContext';
import ScheduleModal from '../components/ScheduleModal';
import ShortsGallery from '../components/ShortsGallery';
import { getStreamTitleSuggestions } from '../services/geminiService';

interface ProfileViewProps {
    onGoLive: (creatorId: string, source: 'camera' | 'screen') => void;
}

const TabButton: React.FC<{ label: string; isActive: boolean; onClick: () => void; badge?: string | number }> = ({ label, isActive, onClick, badge }) => (
    <button
        onClick={onClick}
        className={`px-8 py-4 font-black uppercase tracking-widest text-[11px] transition-all focus:outline-none flex items-center space-x-2 border-b-2 ${
            isActive ? 'border-purple-500 text-white' : 'border-transparent text-gray-600 hover:text-gray-300'
        }`}
    >
        <span>{label}</span>
        {badge !== undefined && (
            <span className={`text-[9px] px-2 py-0.5 rounded-full ${isActive ? 'bg-purple-600 text-white' : 'bg-gray-800 text-gray-500'}`}>
                {badge}
            </span>
        )}
    </button>
);

const StatCard: React.FC<{ icon: React.ReactNode; value: string; label: string; }> = ({ icon, value, label }) => (
    <div className="bg-gray-900/50 p-6 rounded-3xl flex flex-col items-center text-center border border-gray-800 group hover:border-purple-500/30 transition-all hover:bg-gray-900 duration-500">
        <div className="p-4 bg-gray-800/50 rounded-2xl mb-4 group-hover:scale-110 transition-transform">
            {icon}
        </div>
        <p className="text-2xl font-black text-white">{value}</p>
        <p className="text-[10px] text-gray-500 uppercase font-black tracking-widest mt-1">{label}</p>
    </div>
);

const ProfileView: React.FC<ProfileViewProps> = ({ onGoLive }) => {
    const { currentUser, scheduleStream, logout, updateProfileLinks, addShortVideo, topUpCoins, deleteAccount } = useApp();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [activeTab, setActiveTab] = useState('broadcast');

    const [isDeleting, setIsDeleting] = useState(false);
    const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

    // State for Broadcast tab
    const [topic, setTopic] = useState('');
    const [suggestions, setSuggestions] = useState<string[]>([]);
    const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);
    
    // State for About tab
    const [isEditingLinks, setIsEditingLinks] = useState(false);
    const [link1, setLink1] = useState({ title: '', url: '' });
    const [link2, setLink2] = useState({ title: '', url: '' });
    const [link3, setLink3] = useState({ title: '', url: '' });

    // State for Shorts upload (simulated)
    const [isUploadingShort, setIsUploadingShort] = useState(false);
    const [newShortTitle, setNewShortTitle] = useState('');

    useEffect(() => {
        if (currentUser?.links) {
            setLink1(currentUser.links[0] || { title: '', url: '' });
            setLink2(currentUser.links[1] || { title: '', url: '' });
            setLink3(currentUser.links[2] || { title: '', url: '' });
        }
    }, [currentUser]);

    const handleSchedule = (date: Date, duration: number | null, recurrence: 'daily' | 'weekly' | null) => {
        if (currentUser) {
            scheduleStream(currentUser.id, date, duration, recurrence);
        }
    };

    const handleGetSuggestions = async () => {
        if (!topic.trim()) return;
        setIsLoadingSuggestions(true);
        setSuggestions([]);
        const result = await getStreamTitleSuggestions(topic);
        setSuggestions(result);
        setIsLoadingSuggestions(false);
    };

    const handleSaveLinks = () => {
        const links = [link1, link2, link3].filter(link => link.title.trim() && link.url.trim());
        updateProfileLinks(links);
        setIsEditingLinks(false);
    };

    const handleUploadShort = () => {
        if (!newShortTitle.trim()) return;
        
        const success = addShortVideo({
            title: newShortTitle.trim(),
            thumbnail: `https://picsum.photos/seed/${Date.now()}/400/700`,
            videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
        });

        if (success) {
            setIsUploadingShort(false);
            setNewShortTitle('');
        }
    };

    const handleDeleteAccount = async () => {
        setIsDeleting(true);
        const success = await deleteAccount();
        if (!success) {
            alert("Failed to delete account. You may need to log in again to perform this action.");
            setIsDeleting(false);
            setShowDeleteConfirm(false);
        }
    };

    const handleTopUp = (amount: number) => {
        topUpCoins(amount);
    };

    if (!currentUser) return <div className="text-center p-8 bg-gray-950 h-full flex flex-col justify-center">
        <p className="text-xl font-bold mb-4 text-white">Identity verification required.</p>
        <p className="text-gray-500">Please authenticate to access your dashboard.</p>
    </div>;

    const BroadcastTab = () => (
        <div className="animate-fade-in-left grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
                <div className="bg-gray-900 p-8 rounded-[2.5rem] border border-gray-800 space-y-6">
                    <h2 className="text-2xl font-black text-white">Start New Broadcast</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <button
                            onClick={() => onGoLive(currentUser.id, 'camera')}
                            className="group relative w-full bg-red-600 text-white font-black py-6 rounded-3xl text-lg flex items-center justify-center space-x-3 hover:bg-red-700 transition-all overflow-hidden shadow-xl shadow-red-500/10"
                        >
                            <span className="w-3 h-3 bg-white rounded-full animate-pulse shadow-[0_0_10px_white]"></span>
                            <span className="relative z-10">Start Camera</span>
                        </button>
                        <button
                            onClick={() => onGoLive(currentUser.id, 'screen')}
                            className="group relative w-full bg-indigo-600 text-white font-black py-6 rounded-3xl text-lg flex items-center justify-center space-x-3 hover:bg-indigo-700 transition-all overflow-hidden shadow-xl shadow-indigo-500/10"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 relative z-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                            </svg>
                            <span className="relative z-10">Share Screen</span>
                        </button>
                    </div>
                </div>

                <div className="bg-gray-900 p-8 rounded-[2.5rem] border border-gray-800 space-y-6">
                    <div className="flex items-center justify-between">
                        <h2 className="text-xl font-black text-white uppercase tracking-tight">AI Content Planner</h2>
                        <span className="text-[10px] bg-purple-600/20 text-purple-400 px-3 py-1 rounded-full font-black tracking-widest uppercase">Beta</span>
                    </div>
                    <p className="text-gray-500 text-sm leading-relaxed">Enter your stream topic and our AI will generate optimized titles to maximize your engagement.</p>
                    <div className="flex space-x-3">
                        <input
                            type="text"
                            value={topic}
                            onChange={(e) => setTopic(e.target.value)}
                            placeholder="Gaming, Tutorial, Chat..."
                            className="flex-grow p-4 bg-gray-950 border border-gray-800 rounded-2xl text-white focus:ring-2 focus:ring-purple-500 outline-none transition-all placeholder:text-gray-700"
                        />
                        <button
                            onClick={handleGetSuggestions}
                            disabled={isLoadingSuggestions || !topic}
                            className="px-8 py-4 rounded-2xl font-black text-white bg-purple-600 hover:bg-purple-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed uppercase text-xs tracking-widest"
                        >
                            {isLoadingSuggestions ? 'Planning...' : 'Generate'}
                        </button>
                    </div>
                    {suggestions.length > 0 && (
                        <div className="grid grid-cols-1 gap-3">
                            {suggestions.map((s, i) => (
                                <div key={i} className="bg-gray-950 p-4 rounded-2xl text-gray-400 border border-gray-800 hover:border-purple-500/50 transition-all cursor-pointer group flex justify-between items-center" onClick={() => { setTopic(s); setSuggestions([]); }}>
                                    <span className="font-bold text-sm">{s}</span>
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 opacity-0 group-hover:opacity-100 transition-opacity text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                                    </svg>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>

            <div className="space-y-8">
                <div className="bg-gray-900 p-8 rounded-[2.5rem] border border-gray-800 h-full">
                    <h2 className="text-xl font-black text-white uppercase tracking-tight mb-6">Upcoming</h2>
                    <div className="space-y-4">
                        <button
                            onClick={() => setIsModalOpen(true)}
                            className="w-full bg-gray-800/50 border border-dashed border-gray-700 p-6 rounded-[2rem] text-gray-500 hover:text-purple-400 hover:border-purple-500/30 transition-all flex flex-col items-center justify-center space-y-2 group"
                        >
                            <div className="w-12 h-12 bg-gray-900 rounded-full flex items-center justify-center text-xl group-hover:bg-purple-600 group-hover:text-white transition-all">📅</div>
                            <span className="font-black uppercase tracking-widest text-[10px]">Schedule Stream</span>
                        </button>
                        
                        <div className="p-4 bg-gray-950 rounded-2xl border border-gray-800 text-center py-10">
                            <p className="text-gray-600 text-xs font-bold uppercase">No broadcasts scheduled</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );

    const ShortsTab = () => (
        <div className="animate-fade-in-left space-y-8">
            <div className="flex justify-between items-center">
                <div>
                    <h2 className="text-3xl font-black text-white">My Shorts Gallery</h2>
                    <p className="text-gray-500 text-sm mt-1">Short 1:20 format clips for quick audience growth.</p>
                </div>
                {(currentUser.videos?.length || 0) < 7 && !isUploadingShort && (
                    <button 
                        onClick={() => setIsUploadingShort(true)}
                        className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 rounded-2xl font-black transition-all shadow-lg shadow-purple-500/20 active:scale-95 text-xs uppercase tracking-widest"
                    >
                        + New Short
                    </button>
                )}
            </div>

            {isUploadingShort && (
                <div className="bg-gray-900 p-8 rounded-[2.5rem] border border-purple-500/30 mb-8 animate-slide-up shadow-2xl">
                    <h3 className="text-xl font-black mb-6">Create Short</h3>
                    <div className="space-y-4">
                        <input 
                            type="text"
                            placeholder="Catchy title for your clip..."
                            value={newShortTitle}
                            onChange={(e) => setNewShortTitle(e.target.value)}
                            className="w-full p-4 bg-gray-950 border border-gray-800 rounded-2xl focus:ring-2 focus:ring-purple-500 outline-none text-white font-bold"
                        />
                        <div className="flex space-x-3">
                            <button 
                                onClick={handleUploadShort}
                                className="flex-1 bg-purple-600 text-white font-black py-4 rounded-2xl hover:bg-purple-700 transition-colors uppercase text-xs tracking-widest"
                            >
                                Publish Video
                            </button>
                            <button 
                                onClick={() => setIsUploadingShort(false)}
                                className="px-8 py-4 bg-gray-800 text-gray-300 font-bold rounded-2xl hover:bg-gray-700 transition-colors uppercase text-xs tracking-widest"
                            >
                                Cancel
                            </button>
                        </div>
                    </div>
                </div>
            )}

            <div className="bg-gray-900/40 p-2 md:p-8 rounded-[3rem] border border-gray-800">
                <ShortsGallery videos={currentUser.videos || []} />
            </div>
        </div>
    );

    const AboutTab = () => (
        <div className="animate-fade-in-left grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-gray-900 p-8 rounded-[2.5rem] border border-gray-800">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-black uppercase tracking-tight">Social Connect</h3>
                    {!isEditingLinks ? (
                        <button onClick={() => setIsEditingLinks(true)} className="text-purple-400 text-xs font-black uppercase tracking-widest hover:text-purple-300 transition-colors">Manage</button>
                    ) : (
                        <div className="flex space-x-4">
                            <button onClick={handleSaveLinks} className="text-green-500 text-xs font-black uppercase tracking-widest">Save</button>
                            <button onClick={() => setIsEditingLinks(false)} className="text-gray-500 text-xs font-black uppercase tracking-widest">Back</button>
                        </div>
                    )}
                </div>

                {isEditingLinks ? (
                    <div className="space-y-6">
                        {[ 
                            { s: link1, set: setLink1, label: "Platform 1" },
                            { s: link2, set: setLink2, label: "Platform 2" },
                            { s: link3, set: setLink3, label: "Platform 3" }
                        ].map((item, idx) => (
                            <div key={idx} className="space-y-2">
                                <label className="text-[9px] text-gray-600 font-black uppercase tracking-widest px-1">{item.label}</label>
                                <div className="grid grid-cols-2 gap-3">
                                    <input
                                        type="text"
                                        placeholder="Title"
                                        value={item.s.title}
                                        onChange={(e) => item.set({ ...item.s, title: e.target.value })}
                                        className="p-3 bg-gray-950 border border-gray-800 rounded-xl text-xs font-bold"
                                    />
                                    <input
                                        type="text"
                                        placeholder="https://..."
                                        value={item.s.url}
                                        onChange={(e) => item.set({ ...item.s, url: e.target.value })}
                                        className="p-3 bg-gray-950 border border-gray-800 rounded-xl text-xs font-bold"
                                    />
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="space-y-3">
                        {currentUser.links && currentUser.links.length > 0 ? currentUser.links.map((link, idx) => (
                            <div key={idx} className="flex items-center p-4 bg-gray-950 rounded-2xl border border-gray-800 group hover:border-purple-500/30 transition-all">
                                <span className="flex-1 font-black text-sm uppercase tracking-tight">{link.title}</span>
                                <span className="text-gray-600 text-[10px] truncate max-w-[200px] font-mono">{link.url}</span>
                            </div>
                        )) : (
                            <div className="text-center py-10 opacity-30 italic text-sm">No links connected.</div>
                        )}
                    </div>
                )}
            </div>

            <div className="bg-gray-900 p-8 rounded-[2.5rem] border border-gray-800 flex flex-col justify-between">
                <div>
                    <h3 className="text-xl font-black uppercase tracking-tight mb-4 text-red-500">Danger Zone</h3>
                    <p className="text-gray-500 text-sm mb-6">Deleting your account is permanent and will remove all your data, followers, and coin balance. This action cannot be undone.</p>
                </div>
                
                {!showDeleteConfirm ? (
                    <button 
                        onClick={() => setShowDeleteConfirm(true)}
                        className="w-full py-4 bg-red-600/10 text-red-500 font-black rounded-2xl border border-red-600/20 hover:bg-red-600 hover:text-white transition-all uppercase text-xs tracking-widest"
                    >
                        Delete My Account
                    </button>
                ) : (
                    <div className="space-y-3 animate-slide-up">
                        <p className="text-xs font-black text-white uppercase tracking-widest text-center mb-2">Are you absolutely sure?</p>
                        <div className="flex space-x-3">
                            <button 
                                onClick={handleDeleteAccount}
                                disabled={isDeleting}
                                className="flex-1 py-4 bg-red-600 text-white font-black rounded-2xl hover:bg-red-700 transition-all uppercase text-xs tracking-widest disabled:opacity-50"
                            >
                                {isDeleting ? 'Deleting...' : 'Yes, Delete'}
                            </button>
                            <button 
                                onClick={() => setShowDeleteConfirm(false)}
                                disabled={isDeleting}
                                className="flex-1 py-4 bg-gray-800 text-gray-300 font-black rounded-2xl hover:bg-gray-700 transition-all uppercase text-xs tracking-widest disabled:opacity-50"
                            >
                                Cancel
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );

    return (
        <div className="max-w-[1400px] mx-auto p-4 md:p-8 lg:p-12">
            {/* Website Dashboard Header */}
            <header className="mb-12">
                <div className="bg-gray-900 rounded-[3rem] p-8 md:p-12 border border-gray-800 flex flex-col md:flex-row items-center md:items-end justify-between gap-8 relative overflow-hidden group">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-purple-600/5 blur-[120px] pointer-events-none"></div>
                    
                    <div className="flex flex-col md:flex-row items-center md:items-center text-center md:text-left gap-8 relative z-10">
                        <div className="relative">
                            <img className="w-32 h-32 md:w-44 md:h-44 rounded-[2.5rem] border-4 border-purple-500/30 shadow-2xl object-cover transform transition-transform group-hover:scale-105 duration-700" src={currentUser.avatar} alt={currentUser.name} referrerPolicy="no-referrer" loading="lazy" />
                            <div className="absolute -bottom-2 -right-2 bg-emerald-500 p-2.5 rounded-2xl border-4 border-gray-900 shadow-xl group-hover:rotate-12 transition-transform">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-950" fill="currentColor" viewBox="0 0 20 20">
                                    <path d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z" />
                                </svg>
                            </div>
                        </div>
                        <div className="space-y-3">
                            <div className="flex items-center space-x-3 justify-center md:justify-start">
                                <h1 className="text-4xl md:text-5xl font-black text-white tracking-tighter">{currentUser.name}</h1>
                                <span className="bg-purple-600 text-white text-[9px] font-black uppercase tracking-widest px-2.5 py-1 rounded-lg">Verified</span>
                            </div>
                            <p className="text-gray-500 font-mono text-sm tracking-widest">UID_REF: {currentUser.id.split('-')[1]}</p>
                            <div className="flex flex-wrap gap-2 pt-2 justify-center md:justify-start">
                                {currentUser.links?.map((l, i) => (
                                    <span key={i} className="bg-gray-800 px-3 py-1 rounded-full text-[9px] font-black text-gray-400 uppercase tracking-widest">{l.title}</span>
                                ))}
                            </div>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 w-full md:w-auto relative z-10">
                        <StatCard 
                            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>}
                            value={currentUser.followers.toLocaleString()}
                            label="Followers"
                        />
                        <StatCard 
                            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>}
                            value={currentUser.streamCount?.toString() || '0'}
                            label="Broadcasts"
                        />
                    </div>
                </div>
            </header>

            {/* Dashboard Tabs */}
            <div className="mb-10 flex border-b border-gray-800 overflow-x-auto no-scrollbar">
                <TabButton label="Broadcasting" isActive={activeTab === 'broadcast'} onClick={() => setActiveTab('broadcast')} />
                <TabButton label="Shorts Vault" isActive={activeTab === 'shorts'} onClick={() => setActiveTab('shorts')} badge={currentUser.videos?.length || 0} />
                <TabButton label="Account Settings" isActive={activeTab === 'about'} onClick={() => setActiveTab('about')} />
            </div>

            {/* Tab Panels */}
            <div className="pb-32">
                {activeTab === 'broadcast' && <BroadcastTab />}
                {activeTab === 'shorts' && <ShortsTab />}
                {activeTab === 'about' && <AboutTab />}
            </div>

            {isModalOpen && (
                <ScheduleModal
                    onClose={() => setIsModalOpen(false)}
                    onSchedule={handleSchedule}
                />
            )}
        </div>
    );
};

export default ProfileView;
