
import React from 'react';

interface AuthViewProps {
    onLoginClick: () => void;
    onSignUpClick: () => void;
    onCancel?: () => void;
}

const AuthView: React.FC<AuthViewProps> = ({ onLoginClick, onSignUpClick, onCancel }) => {
    return (
        <div className="h-screen w-screen flex flex-col justify-center items-center p-4 bg-gray-900 text-white relative">
            {onCancel && (
                <button 
                    onClick={onCancel}
                    className="absolute top-8 right-8 text-gray-400 hover:text-white transition-colors"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            )}
            <h1 className="text-6xl font-extrabold mb-8 text-center select-none tracking-wide">
                <span className="text-red-400">l</span>
                <span className="text-orange-400">i</span>
                <span className="text-yellow-400">t</span>
                <span className="text-green-400">c</span>
                <span className="text-blue-400">h</span>
                <span className="text-purple-400">i</span>
            </h1>
            <p className="text-gray-400 mb-12 text-lg text-center max-w-xs">Your stage, your audience. Go live and connect with your fans.</p>
            <div className="w-full max-w-xs space-y-4">
                 <button
                    onClick={onSignUpClick}
                    className="w-full bg-purple-600 text-white font-bold py-4 rounded-lg text-lg hover:bg-purple-700 transition-colors transform hover:scale-105 shadow-xl shadow-purple-500/20"
                >
                    Sign Up
                </button>
                <button
                    onClick={onLoginClick}
                    className="w-full bg-gray-700 text-white font-bold py-4 rounded-lg text-lg hover:bg-gray-600 transition-colors"
                >
                    Log In
                </button>
                {onCancel && (
                    <button
                        onClick={onCancel}
                        className="w-full text-gray-500 font-bold py-2 text-sm hover:text-gray-300 transition-colors"
                    >
                        Continue as Guest
                    </button>
                )}
            </div>
        </div>
    );
};

export default AuthView;
