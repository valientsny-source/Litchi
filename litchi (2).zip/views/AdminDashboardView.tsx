
import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../contexts/AppContext';
import { 
    LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
    AreaChart, Area, BarChart, Bar, Cell
} from 'recharts';
import { motion } from 'motion/react';
import { 
    Users, Video, Shield, Megaphone, DollarSign, Activity, 
    TrendingUp, Gift, AlertCircle, Terminal, Settings, Database,
    Search, Filter, Download, RefreshCw
} from 'lucide-react';
import AdminAIAssistant from '../src/components/AdminAIAssistant';

const AdminDashboardView: React.FC = () => {
    const { creators, streams, platformSettings, updatePlatformSettings, suspendUser, streamGiftEvents } = useApp();
    const [announcement, setAnnouncement] = useState(platformSettings.globalAlert || '');
    const [monetization, setMonetization] = useState(platformSettings.monetization || {});
    const [searchQuery, setSearchQuery] = useState('');

    useEffect(() => {
        setAnnouncement(platformSettings.globalAlert || '');
        setMonetization(platformSettings.monetization || {});
    }, [platformSettings.globalAlert, platformSettings.monetization]);

    // Aggregate statistics
    const totalLifetimeCoins = creators.reduce((acc, c) => acc + (c.lifetimeCoins || 0), 0);
    const totalCurrentCoins = creators.reduce((acc, c) => acc + c.coins, 0);
    const liveStreamsCount = Object.values(streams).filter(s => s.isLive).length;
    const totalUsers = creators.length;

    // Flatten gift events for the dashboard
    const allGiftEvents = useMemo(() => {
        return Object.values(streamGiftEvents)
            .flat()
            .sort((a, b) => b.timestamp - a.timestamp)
            .slice(0, 10);
    }, [streamGiftEvents]);

    // Simulated growth data
    const growthData = [
        { name: 'Mon', users: 12, streams: 5 },
        { name: 'Tue', users: 19, streams: 8 },
        { name: 'Wed', users: 15, streams: 12 },
        { name: 'Thu', users: 22, streams: 10 },
        { name: 'Fri', users: 30, streams: 15 },
        { name: 'Sat', users: 45, streams: 25 },
        { name: 'Sun', users: totalUsers, streams: liveStreamsCount },
    ];

    const filteredUsers = creators.filter(u => 
        u.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        u.id.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const MetricCard: React.FC<{ label: string; value: string | number; color: string; icon: React.ReactNode }> = ({ label, value, color, icon }) => (
        <motion.div 
            whileHover={{ y: -5 }}
            className="bg-gray-900 p-6 rounded-3xl border border-gray-800 shadow-xl relative overflow-hidden group"
        >
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                {icon}
            </div>
            <p className="text-gray-500 text-[10px] font-black uppercase tracking-[0.2em] mb-2">{label}</p>
            <div className="flex items-end space-x-2">
                <p className={`text-4xl font-black ${color}`}>{value}</p>
                <div className="flex items-center text-emerald-500 text-[10px] font-bold mb-1">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    +12%
                </div>
            </div>
        </motion.div>
    );

    return (
        <div className="p-6 md:p-12 max-w-[1600px] mx-auto space-y-12 pb-32">
            <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="space-y-1">
                    <div className="flex items-center space-x-3">
                        <div className="bg-emerald-600 p-2 rounded-xl">
                            <Terminal className="w-6 h-6 text-white" />
                        </div>
                        <h1 className="text-4xl font-black text-white tracking-tighter uppercase">Litchi Console</h1>
                    </div>
                    <p className="text-emerald-500 font-mono text-[10px] tracking-[0.3em] font-black">SECURITY STATUS: SECURE | ROLE: ROOT_ADMIN</p>
                </div>
                <div className="flex items-center space-x-4">
                    <div className="hidden md:flex items-center space-x-3 bg-gray-900 border border-gray-800 p-4 rounded-2xl">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_10px_rgba(16,185,129,0.5)]"></div>
                        <span className="text-gray-400 text-[10px] font-black uppercase tracking-widest">System Status: Nominal</span>
                    </div>
                    <button className="p-4 bg-gray-900 border border-gray-800 rounded-2xl text-gray-400 hover:text-white transition-colors">
                        <RefreshCw className="w-5 h-5" />
                    </button>
                </div>
            </header>

            {/* Platform Stats Grid */}
            <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <MetricCard label="Active Broadcasts" value={liveStreamsCount} color="text-red-500" icon={<Video className="w-12 h-12" />} />
                <MetricCard label="Registered Entities" value={totalUsers} color="text-white" icon={<Users className="w-12 h-12" />} />
                <MetricCard label="Circulating Wealth" value={totalCurrentCoins.toLocaleString()} color="text-yellow-500" icon={<DollarSign className="w-12 h-12" />} />
                <MetricCard label="Lifetime Revenue" value={totalLifetimeCoins.toLocaleString()} color="text-emerald-500" icon={<Activity className="w-12 h-12" />} />
            </section>

            {/* Analytics Section */}
            <section className="grid grid-cols-1 xl:grid-cols-3 gap-8">
                <div className="xl:col-span-2 bg-gray-900 p-8 rounded-[2.5rem] border border-gray-800 space-y-8">
                    <div className="flex items-center justify-between">
                        <h2 className="text-xl font-black uppercase tracking-tight flex items-center space-x-3">
                            <TrendingUp className="w-5 h-5 text-emerald-500" />
                            <span>Platform Growth Analytics</span>
                        </h2>
                        <div className="flex space-x-2">
                            {['7D', '30D', 'ALL'].map(t => (
                                <button key={t} className={`px-3 py-1 rounded-lg text-[10px] font-black ${t === '7D' ? 'bg-emerald-600 text-white' : 'bg-gray-800 text-gray-500'}`}>{t}</button>
                            ))}
                        </div>
                    </div>
                    <div className="h-[300px] w-full">
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={growthData}>
                                <defs>
                                    <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" vertical={false} />
                                <XAxis dataKey="name" stroke="#4b5563" fontSize={10} fontWeight="bold" axisLine={false} tickLine={false} />
                                <YAxis stroke="#4b5563" fontSize={10} fontWeight="bold" axisLine={false} tickLine={false} />
                                <Tooltip 
                                    contentStyle={{ backgroundColor: '#111827', border: '1px solid #374151', borderRadius: '12px' }}
                                    itemStyle={{ color: '#10b981', fontSize: '12px', fontWeight: 'bold' }}
                                />
                                <Area type="monotone" dataKey="users" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorUsers)" />
                                <Area type="monotone" dataKey="streams" stroke="#ef4444" strokeWidth={3} fill="transparent" />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                <div className="bg-gray-900 p-8 rounded-[2.5rem] border border-gray-800 space-y-8">
                    <h2 className="text-xl font-black uppercase tracking-tight flex items-center space-x-3">
                        <Gift className="w-5 h-5 text-purple-500" />
                        <span>Recent Transactions</span>
                    </h2>
                    <div className="space-y-4">
                        {allGiftEvents.length > 0 ? allGiftEvents.map((event) => (
                            <div key={event.id} className="flex items-center justify-between p-4 bg-gray-800/50 rounded-2xl border border-gray-700/50">
                                <div className="flex items-center space-x-3">
                                    <div className="text-xl">{event.gift.icon}</div>
                                    <div>
                                        <p className="text-xs font-black text-white">{event.sender.name}</p>
                                        <p className="text-[10px] text-gray-500 font-bold uppercase">{event.gift.name}</p>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <p className="text-xs font-black text-yellow-500">+{event.gift.cost} 💎</p>
                                    <p className="text-[8px] text-gray-600 font-bold uppercase">{new Date(event.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                                </div>
                            </div>
                        )) : (
                            <div className="text-center py-12 text-gray-600 font-bold text-xs uppercase tracking-widest">No recent events</div>
                        )}
                    </div>
                    <button className="w-full py-4 bg-gray-800 hover:bg-gray-700 text-gray-400 text-[10px] font-black uppercase tracking-widest rounded-2xl transition-all border border-gray-700">View All Transactions</button>
                </div>
            </section>

            {/* Platform Controls */}
            <section className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-gray-900 p-10 rounded-[3rem] border border-gray-800 space-y-8">
                    <h2 className="text-2xl font-black uppercase tracking-tight flex items-center space-x-3">
                        <Shield className="w-6 h-6 text-emerald-500" />
                        <span>Security Protocols</span>
                    </h2>
                    
                    <div className="space-y-4">
                        <div className="flex items-center justify-between p-6 bg-gray-800/30 rounded-[2rem] border border-gray-800 hover:border-red-500/30 transition-all group">
                            <div className="flex items-center space-x-4">
                                <div className={`p-3 rounded-xl ${platformSettings.maintenanceMode ? 'bg-red-500/10 text-red-500' : 'bg-gray-700 text-gray-500'}`}>
                                    <AlertCircle className="w-6 h-6" />
                                </div>
                                <div>
                                    <p className="font-black text-white uppercase tracking-tight">Maintenance Mode</p>
                                    <p className="text-[10px] text-gray-500 font-bold uppercase">Redirect all traffic to landing page</p>
                                </div>
                            </div>
                            <button 
                                onClick={() => updatePlatformSettings({ maintenanceMode: !platformSettings.maintenanceMode })}
                                className={`w-16 h-9 rounded-full transition-all relative p-1 ${platformSettings.maintenanceMode ? 'bg-red-600 shadow-[0_0_15px_rgba(220,38,38,0.4)]' : 'bg-gray-700'}`}
                            >
                                <div className={`w-7 h-7 bg-white rounded-full transition-all shadow-lg ${platformSettings.maintenanceMode ? 'translate-x-7' : 'translate-x-0'}`}></div>
                            </button>
                        </div>

                        <div className="flex items-center justify-between p-6 bg-gray-800/30 rounded-[2rem] border border-gray-800 hover:border-emerald-500/30 transition-all group">
                            <div className="flex items-center space-x-4">
                                <div className={`p-3 rounded-xl ${platformSettings.disableSignups ? 'bg-red-500/10 text-red-500' : 'bg-gray-700 text-gray-500'}`}>
                                    <Users className="w-6 h-6" />
                                </div>
                                <div>
                                    <p className="font-black text-white uppercase tracking-tight">Halt New Signups</p>
                                    <p className="text-[10px] text-gray-500 font-bold uppercase">Disable registration for new entities</p>
                                </div>
                            </div>
                            <button 
                                onClick={() => updatePlatformSettings({ disableSignups: !platformSettings.disableSignups })}
                                className={`w-16 h-9 rounded-full transition-all relative p-1 ${platformSettings.disableSignups ? 'bg-red-600 shadow-[0_0_15px_rgba(220,38,38,0.4)]' : 'bg-gray-700'}`}
                            >
                                <div className={`w-7 h-7 bg-white rounded-full transition-all shadow-lg ${platformSettings.disableSignups ? 'translate-x-7' : 'translate-x-0'}`}></div>
                            </button>
                        </div>
                    </div>
                </div>

                <div className="bg-gray-900 p-10 rounded-[3rem] border border-gray-800 space-y-8">
                    <h2 className="text-2xl font-black uppercase tracking-tight flex items-center space-x-3">
                        <Megaphone className="w-6 h-6 text-emerald-500" />
                        <span>Global Broadcast</span>
                    </h2>
                    <div className="space-y-6">
                        <div className="relative">
                            <textarea 
                                className="w-full h-40 bg-gray-800 border border-gray-700 rounded-[2rem] p-6 text-sm text-white focus:ring-2 focus:ring-emerald-500 outline-none transition-all placeholder:text-gray-600 font-bold"
                                placeholder="Enter system-wide announcement..."
                                onChange={(e) => setAnnouncement(e.target.value)}
                                value={announcement}
                            ></textarea>
                            <div className="absolute top-4 right-4 bg-gray-900 px-3 py-1 rounded-full border border-gray-700">
                                <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest">Broadcast Channel: All</p>
                            </div>
                        </div>
                        <div className="flex justify-end">
                            <button 
                                onClick={() => updatePlatformSettings({ globalAlert: announcement || null })}
                                className="bg-emerald-600 hover:bg-emerald-500 text-white font-black py-4 px-12 rounded-2xl transition-all shadow-xl shadow-emerald-600/20 uppercase tracking-widest text-xs active:scale-95"
                            >
                                Publish to Feed
                            </button>
                        </div>
                    </div>
                </div>
            </section>

            {/* Monetization Engine */}
            <section className="bg-gray-900 p-10 rounded-[3rem] border border-gray-800 space-y-10">
                <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-black uppercase tracking-tight flex items-center space-x-3">
                        <DollarSign className="w-6 h-6 text-yellow-500" />
                        <span>Monetization Engine</span>
                    </h2>
                    <div className="flex items-center space-x-2 bg-yellow-500/10 border border-yellow-500/20 px-4 py-2 rounded-xl">
                        <Activity className="w-4 h-4 text-yellow-500" />
                        <span className="text-yellow-500 text-[10px] font-black uppercase tracking-widest">Engine Active</span>
                    </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {[
                        { label: 'Site Head Injection', key: 'headCode', desc: 'Injected into the <head> section.' },
                        { label: 'Home Feed Placement', key: 'feedCode', desc: 'Injected between feed items.' },
                        { label: 'Site Footer Injection', key: 'footerCode', desc: 'Injected at the bottom of the page.' }
                    ].map((item) => (
                        <div key={item.key} className="space-y-4">
                            <label className="text-xs font-black text-gray-500 uppercase tracking-widest ml-2">{item.label}</label>
                            <div className="relative group">
                                <textarea 
                                    className="w-full h-48 bg-gray-800 border border-gray-700 rounded-[2rem] p-6 text-xs focus:ring-2 focus:ring-yellow-500 outline-none font-mono text-gray-300 transition-all group-hover:border-yellow-500/30"
                                    placeholder="<script>...</script>"
                                    value={(monetization as any)[item.key] || ''}
                                    onChange={(e) => setMonetization({ ...monetization, [item.key]: e.target.value })}
                                />
                                <div className="absolute bottom-4 right-4">
                                    <Settings className="w-4 h-4 text-gray-600" />
                                </div>
                            </div>
                            <p className="text-[10px] text-gray-600 font-bold uppercase ml-2">{item.desc}</p>
                        </div>
                    ))}
                </div>
                <div className="flex justify-end pt-4">
                    <button 
                        onClick={() => updatePlatformSettings({ monetization })}
                        className="bg-yellow-600 hover:bg-yellow-500 text-white font-black py-4 px-12 rounded-2xl transition-all shadow-xl shadow-yellow-600/20 uppercase tracking-widest text-xs active:scale-95"
                    >
                        Deploy Ad Config
                    </button>
                </div>
            </section>

            {/* User Registry */}
            <section className="bg-gray-900 rounded-[3rem] border border-gray-800 overflow-hidden shadow-2xl">
                <div className="p-10 border-b border-gray-800 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                    <div className="space-y-1">
                        <h2 className="text-2xl font-black uppercase tracking-tight flex items-center space-x-3">
                            <Database className="w-6 h-6 text-blue-500" />
                            <span>User Registry Audit</span>
                        </h2>
                        <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Total Records: {totalUsers}</p>
                    </div>
                    <div className="flex items-center space-x-4 w-full md:w-auto">
                        <div className="relative flex-1 md:w-80">
                            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                            <input 
                                type="text" 
                                placeholder="Search by name or ID..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="w-full bg-gray-800 border border-gray-700 rounded-2xl py-3 pl-12 pr-4 text-sm text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                            />
                        </div>
                        <button className="p-3 bg-gray-800 border border-gray-700 rounded-2xl text-gray-400 hover:text-white transition-colors">
                            <Filter className="w-5 h-5" />
                        </button>
                        <button className="p-3 bg-gray-800 border border-gray-700 rounded-2xl text-gray-400 hover:text-white transition-colors">
                            <Download className="w-5 h-5" />
                        </button>
                    </div>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                        <thead className="bg-gray-950 text-gray-600 uppercase text-[10px] font-black tracking-[0.2em]">
                            <tr>
                                <th className="px-10 py-6">Entity Identity</th>
                                <th className="px-10 py-6">Wealth & Influence</th>
                                <th className="px-10 py-6 text-center">Status</th>
                                <th className="px-10 py-6 text-right">Access Control</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-800">
                            {filteredUsers.map(user => (
                                <tr key={user.id} className="hover:bg-white/[0.02] transition-colors group">
                                    <td className="px-10 py-6">
                                        <div className="flex items-center space-x-4">
                                            <div className="relative">
                                                <img src={user.avatar} className="w-12 h-12 rounded-2xl grayscale group-hover:grayscale-0 transition-all duration-500 object-cover" alt="" referrerPolicy="no-referrer" loading="lazy" />
                                                <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-4 border-gray-900 ${user.isSuspended ? 'bg-red-500' : 'bg-emerald-500'}`}></div>
                                            </div>
                                            <div>
                                                <p className="font-black text-white text-base tracking-tight">{user.name}</p>
                                                <p className="text-[10px] text-gray-600 font-mono uppercase tracking-widest">{user.id}</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-10 py-6">
                                        <div className="flex items-center space-x-6">
                                            <div>
                                                <p className="text-[10px] text-gray-500 font-black uppercase mb-1">Followers</p>
                                                <p className="text-white font-black">{user.followers.toLocaleString()}</p>
                                            </div>
                                            <div>
                                                <p className="text-[10px] text-gray-500 font-black uppercase mb-1">Coins</p>
                                                <p className="text-yellow-500 font-black">{user.coins.toLocaleString()}</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-10 py-6 text-center">
                                        <span className={`px-3 py-1.5 rounded-xl text-[10px] font-black tracking-widest ${user.isSuspended ? 'bg-red-500/10 text-red-500 border border-red-500/20' : 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20'}`}>
                                            {user.isSuspended ? 'SUSPENDED' : 'ACTIVE'}
                                        </span>
                                    </td>
                                    <td className="px-10 py-6 text-right">
                                        <button 
                                            onClick={() => suspendUser(user.id)}
                                            className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all active:scale-95 ${user.isSuspended ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/20' : 'bg-red-600/10 hover:bg-red-600 text-red-500 hover:text-white border border-red-500/20'}`}
                                        >
                                            {user.isSuspended ? 'Restore Access' : 'Revoke Access'}
                                        </button>
                                    </td>
                                </tr>
                            ))}
                            {filteredUsers.length === 0 && (
                                <tr>
                                    <td colSpan={4} className="px-10 py-20 text-center text-gray-600 font-black uppercase tracking-[0.3em] text-xs">No entities found matching query</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </section>

            {/* AI Assistant Integration */}
            <AdminAIAssistant />
        </div>
    );
};

export default AdminDashboardView;
