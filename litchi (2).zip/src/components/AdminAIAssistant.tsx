
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { motion, AnimatePresence } from "motion/react";
import { MessageSquare, Send, X, Bot, Sparkles, Terminal, ChevronDown, ChevronUp } from "lucide-react";
import Markdown from 'react-markdown';
import { useApp } from '../../contexts/AppContext';
import { Stream } from '../../types';

const AdminAIAssistant: React.FC = () => {
    const { creators, streams, platformSettings } = useApp();
    const [isOpen, setIsOpen] = useState(false);
    const [input, setInput] = useState('');
    const [messages, setMessages] = useState<{ role: 'user' | 'assistant'; content: string }[]>([
        { role: 'assistant', content: "Hello Admin! I'm your Litchi Platform Consultant. I have access to real-time platform data. How can I help you optimize the ecosystem today?" }
    ]);
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const handleSend = async () => {
        if (!input.trim() || isLoading) return;

        const userMessage = input.trim();
        setInput('');
        setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
        setIsLoading(true);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
            
            // Prepare context for the AI
            const platformContext = {
                totalUsers: creators.length,
                activeStreams: Object.values(streams).filter((s: Stream) => s.isLive).length,
                maintenanceMode: platformSettings.maintenanceMode,
                signupsDisabled: platformSettings.disableSignups,
                creators: creators.map(c => ({
                    name: c.name,
                    followers: c.followers,
                    coins: c.coins,
                    isSuspended: c.isSuspended
                })).slice(0, 20) // Limit to top 20 for context size
            };

            const systemInstruction = `
                You are an expert AI Platform Consultant for Litchi, a livestreaming platform.
                Your goal is to assist the administrator in managing and improving the platform.
                
                CURRENT PLATFORM DATA:
                ${JSON.stringify(platformContext, null, 2)}
                
                GUIDELINES:
                1. Be professional, data-driven, and proactive.
                2. Suggest features based on current trends (e.g., gamification, monetization, safety).
                3. Help analyze user engagement and suggest improvements.
                4. If asked about technical improvements, suggest modern web technologies.
                5. Keep responses concise and formatted with Markdown.
                6. You can suggest specific SQL-like queries or logic for future implementations.
            `;

            const response = await ai.models.generateContent({
                model: "gemini-3-flash-preview",
                contents: userMessage,
                config: {
                    systemInstruction: systemInstruction,
                },
            });

            const aiResponse = response.text || "I'm sorry, I couldn't process that request.";
            setMessages(prev => [...prev, { role: 'assistant', content: aiResponse }]);
        } catch (error) {
            console.error("AI Error:", error);
            setMessages(prev => [...prev, { role: 'assistant', content: "Error: I'm having trouble connecting to my neural core. Please check the console for details." }]);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="fixed bottom-6 right-6 z-50">
            <AnimatePresence>
                {isOpen && (
                    <motion.div 
                        initial={{ opacity: 0, y: 20, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 20, scale: 0.95 }}
                        className="bg-gray-900 border border-emerald-500/30 w-[400px] h-[600px] rounded-3xl shadow-2xl flex flex-col overflow-hidden mb-4"
                    >
                        {/* Header */}
                        <div className="bg-emerald-600 p-4 flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                                <div className="bg-white/20 p-2 rounded-xl">
                                    <Bot className="w-5 h-5 text-white" />
                                </div>
                                <div>
                                    <h3 className="text-white font-black text-sm uppercase tracking-widest">Litchi Intelligence</h3>
                                    <p className="text-emerald-200 text-[10px] font-bold">CORE VERSION 3.1-FLASH</p>
                                </div>
                            </div>
                            <button onClick={() => setIsOpen(false)} className="text-white/60 hover:text-white transition-colors">
                                <X className="w-5 h-5" />
                            </button>
                        </div>

                        {/* Messages */}
                        <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
                            {messages.map((msg, i) => (
                                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                                    <div className={`max-w-[85%] p-3 rounded-2xl text-sm ${
                                        msg.role === 'user' 
                                            ? 'bg-emerald-600 text-white rounded-tr-none' 
                                            : 'bg-gray-800 text-gray-200 border border-gray-700 rounded-tl-none'
                                    }`}>
                                        <div className="prose prose-invert prose-sm max-w-none">
                                            <Markdown>{msg.content}</Markdown>
                                        </div>
                                    </div>
                                </div>
                            ))}
                            {isLoading && (
                                <div className="flex justify-start">
                                    <div className="bg-gray-800 p-4 rounded-2xl border border-gray-700 rounded-tl-none flex items-center space-x-2">
                                        <div className="w-2 h-2 bg-emerald-500 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
                                        <div className="w-2 h-2 bg-emerald-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                                        <div className="w-2 h-2 bg-emerald-500 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                                    </div>
                                </div>
                            )}
                            <div ref={messagesEndRef} />
                        </div>

                        {/* Input */}
                        <div className="p-4 bg-gray-950 border-t border-gray-800">
                            <div className="relative">
                                <input 
                                    type="text" 
                                    value={input}
                                    onChange={(e) => setInput(e.target.value)}
                                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                                    placeholder="Ask for platform insights..."
                                    className="w-full bg-gray-900 border border-gray-700 rounded-xl py-3 pl-4 pr-12 text-sm text-white focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                                />
                                <button 
                                    onClick={handleSend}
                                    disabled={isLoading || !input.trim()}
                                    className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-emerald-500 hover:text-emerald-400 disabled:text-gray-600 transition-colors"
                                >
                                    <Send className="w-5 h-5" />
                                </button>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            <button 
                onClick={() => setIsOpen(!isOpen)}
                className={`p-4 rounded-full shadow-2xl transition-all hover:scale-110 active:scale-95 flex items-center justify-center ${
                    isOpen ? 'bg-gray-800 text-emerald-500 border border-emerald-500/30' : 'bg-emerald-600 text-white'
                }`}
            >
                {isOpen ? <ChevronDown className="w-6 h-6" /> : <Sparkles className="w-6 h-6" />}
            </button>
        </div>
    );
};

export default AdminAIAssistant;
