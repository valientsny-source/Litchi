
import React, { createContext, useContext, useState, ReactNode, useCallback, useEffect } from 'react';
import { auth, db } from '../firebase';
import { onAuthStateChanged, signOut, deleteUser } from 'firebase/auth';
import { doc, getDoc, setDoc, onSnapshot, collection, query, deleteDoc } from 'firebase/firestore';
import type { Creator, Stream, Gift, GiftEvent, ShortVideo, PlatformSettings } from '../types';
import { handleFirestoreError, OperationType } from '../src/lib/firestoreUtils';

interface AppContextType {
    creators: Creator[];
    userAccounts: Creator[];
    currentUser: Creator | null;
    following: string[];
    streams: Record<string, Stream>;
    streamCoinTotals: Record<string, number>;
    streamGiftEvents: Record<string, GiftEvent[]>;
    platformSettings: PlatformSettings;
    toggleFollow: (creatorId: string) => void;
    goLive: (creatorId: string) => void;
    endStream: (creatorId: string) => void;
    scheduleStream: (creatorId: string, time: Date, duration: number | null, recurrence: 'daily' | 'weekly' | null) => void;
    getStreamByCreatorId: (creatorId: string) => Stream | undefined;
    signup: (name: string) => void;
    login: (creatorId: string) => void;
    logout: () => void;
    sendGift: (creatorId: string, gift: Gift) => Promise<boolean>;
    supportCreator: (creatorId: string, amount: number) => Promise<boolean>;
    updateProfileLinks: (links: { title: string; url: string }[]) => void;
    addShortVideo: (video: Omit<ShortVideo, 'id' | 'timestamp' | 'duration'>) => Promise<boolean>;
    updatePlatformSettings: (settings: Partial<PlatformSettings>) => void;
    suspendUser: (userId: string) => void;
    topUpCoins: (amount: number) => void;
    deleteAccount: () => Promise<boolean>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const INITIAL_CREATORS: Creator[] = [];

const MOCK_STREAMS: Record<string, Stream> = {};

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [allCreators, setAllCreators] = useState<Creator[]>([...INITIAL_CREATORS]);
    const [userCreators, setUserCreators] = useState<Creator[]>([]);
    const [currentUser, setCurrentUser] = useState<Creator | null>(null);
    const [following, setFollowing] = useState<string[]>([]);
    const [streams, setStreams] = useState<Record<string, Stream>>(MOCK_STREAMS);
    const [streamCoinTotals, setStreamCoinTotals] = useState<Record<string, number>>({});
    const [streamGiftEvents, setStreamGiftEvents] = useState<Record<string, GiftEvent[]>>({});
    const [platformSettings, setPlatformSettings] = useState<PlatformSettings>({
        maintenanceMode: false,
        disableSignups: false,
        globalAlert: null,
        isPublished: true
    });

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, async (user) => {
            if (user) {
                const userRef = doc(db, 'users', user.uid);
                const path = `users/${user.uid}`;
                const unsubscribeUser = onSnapshot(userRef, (docSnap) => {
                    if (docSnap.exists()) {
                        const userData = docSnap.data() as Creator;
                        setCurrentUser(userData);
                        
                        // Also update userCreators list if needed
                        setUserCreators(prev => {
                            const exists = prev.find(u => u.id === userData.id);
                            if (exists) {
                                return prev.map(u => u.id === userData.id ? userData : u);
                            }
                            return [...prev, userData];
                        });
                    }
                }, (error) => {
                    handleFirestoreError(error, OperationType.GET, path);
                });
                return () => unsubscribeUser();
            } else {
                setCurrentUser(null);
            }
        });

        // Fetch all users for the platform
        const usersRef = collection(db, 'users');
        const usersPath = 'users';
        const unsubscribeUsers = onSnapshot(usersRef, (snapshot) => {
            const users: Creator[] = [];
            snapshot.forEach((doc) => {
                users.push(doc.data() as Creator);
            });
            setUserCreators(users);
        }, (error) => {
            handleFirestoreError(error, OperationType.LIST, usersPath);
        });

        // Fetch platform settings
        const settingsRef = doc(db, 'settings', 'platform');
        const settingsPath = 'settings/platform';
        const unsubscribeSettings = onSnapshot(settingsRef, (docSnap) => {
            if (docSnap.exists()) {
                setPlatformSettings(prev => ({ ...prev, ...docSnap.data() as PlatformSettings }));
            }
        }, (error) => {
            handleFirestoreError(error, OperationType.GET, settingsPath);
        });

        return () => {
            unsubscribe();
            unsubscribeUsers();
            unsubscribeSettings();
        };
    }, []);

    const signup = useCallback((name: string) => {
        // Handled by Firebase Auth in SignUpView now
    }, []);

    const login = useCallback((creatorId: string) => {
        // Handled by Firebase Auth in LoginView now
    }, []);

    const logout = useCallback(() => {
        signOut(auth).catch(console.error);
    }, []);

    const toggleFollow = useCallback(async (creatorId: string) => {
        setFollowing(prev => {
            const isFollowing = prev.includes(creatorId);
            const newFollowing = isFollowing
                ? prev.filter(id => id !== creatorId)
                : [...prev, creatorId];
            
            setAllCreators(current => current.map(c => {
                if (c.id === creatorId) {
                    return { ...c, followers: c.followers + (isFollowing ? -1 : 1) };
                }
                return c;
            }));
            setUserCreators(current => current.map(c => {
                if (c.id === creatorId) {
                    return { ...c, followers: c.followers + (isFollowing ? -1 : 1) };
                }
                return c;
            }));

            // Async update to Firestore
            const creator = userCreators.find(c => c.id === creatorId);
            if (creator) {
                const updatedFollowers = creator.followers + (isFollowing ? -1 : 1);
                const path = `users/${creatorId}`;
                setDoc(doc(db, 'users', creatorId), { followers: updatedFollowers }, { merge: true })
                    .catch(error => handleFirestoreError(error, OperationType.UPDATE, path));
            }

            return newFollowing;
        });
    }, [userCreators]);

    const goLive = useCallback(async (creatorId: string) => {
        setStreams(prev => ({
            ...prev,
            [creatorId]: { creatorId, isLive: true, scheduledTime: null, durationMinutes: null, recurrence: null, endedAt: null }
        }));
        setStreamCoinTotals(prev => ({...prev, [creatorId]: 0}));
        setStreamGiftEvents(prev => ({...prev, [creatorId]: []}));

        if (currentUser && currentUser.id === creatorId) {
            const updatedUser = {
                ...currentUser,
                streamCount: (currentUser.streamCount || 0) + 1,
            };
            setCurrentUser(updatedUser);
            const path = `users/${creatorId}`;
            try {
                await setDoc(doc(db, 'users', creatorId), updatedUser, { merge: true });
            } catch (error) {
                handleFirestoreError(error, OperationType.UPDATE, path);
            }
        }
    }, [currentUser]);

    const endStream = useCallback(async (creatorId: string) => {
        setStreams(prev => ({
            ...prev,
            [creatorId]: { ...prev[creatorId], isLive: false, endedAt: Date.now() }
        }));
        if (currentUser && currentUser.id === creatorId) {
            const streamEarnings = streamCoinTotals[creatorId] || 0;
            const updatedUser = {
                ...currentUser,
                lifetimeCoins: (currentUser.lifetimeCoins || 0) + streamEarnings,
            };
            setCurrentUser(updatedUser);
            const path = `users/${creatorId}`;
            try {
                await setDoc(doc(db, 'users', creatorId), updatedUser, { merge: true });
            } catch (error) {
                handleFirestoreError(error, OperationType.UPDATE, path);
            }
        }
    }, [currentUser, streamCoinTotals]);

    const scheduleStream = useCallback((creatorId: string, time: Date, duration: number | null, recurrence: 'daily' | 'weekly' | null) => {
        setStreams(prev => ({
            ...prev,
            [creatorId]: { creatorId, isLive: false, scheduledTime: time, durationMinutes: duration, recurrence }
        }));
    }, []);
    
    const sendGift = useCallback(async (creatorId: string, gift: Gift): Promise<boolean> => {
        if (!currentUser || currentUser.coins < gift.cost) {
            return false;
        }

        const updatedUser = { ...currentUser, coins: currentUser.coins - gift.cost };
        setCurrentUser(updatedUser);
        const path = `users/${currentUser.id}`;
        try {
            await setDoc(doc(db, 'users', currentUser.id), updatedUser, { merge: true });
        } catch (error) {
            handleFirestoreError(error, OperationType.UPDATE, path);
        }

        setStreamCoinTotals(prev => ({
            ...prev,
            [creatorId]: (prev[creatorId] || 0) + gift.cost,
        }));

        const newGiftEvent: GiftEvent = {
            id: `gift-${Date.now()}`,
            sender: {
                id: currentUser.id,
                name: currentUser.name,
            },
            gift,
            timestamp: Date.now(),
        };
        setStreamGiftEvents(prev => ({
            ...prev,
            [creatorId]: [...(prev[creatorId] || []), newGiftEvent],
        }));

        return true;
    }, [currentUser]);

    const supportCreator = useCallback(async (creatorId: string, amount: number): Promise<boolean> => {
        if (!currentUser || currentUser.coins < amount) {
            return false;
        }

        const updatedUser = { ...currentUser, coins: currentUser.coins - amount };
        setCurrentUser(updatedUser);
        const path = `users/${currentUser.id}`;
        try {
            await setDoc(doc(db, 'users', currentUser.id), updatedUser, { merge: true });
        } catch (error) {
            handleFirestoreError(error, OperationType.UPDATE, path);
        }

        const creator = userCreators.find(u => u.id === creatorId);
        if (creator) {
            const updatedCreator = { ...creator, lifetimeCoins: (creator.lifetimeCoins || 0) + amount };
            const creatorPath = `users/${creatorId}`;
            try {
                await setDoc(doc(db, 'users', creatorId), updatedCreator, { merge: true });
            } catch (error) {
                handleFirestoreError(error, OperationType.UPDATE, creatorPath);
            }
        }

        return true;
    }, [currentUser, userCreators]);
    
    const updateProfileLinks = useCallback(async (links: { title: string; url: string }[]) => {
        if (currentUser) {
            const updatedUser = { ...currentUser, links };
            setCurrentUser(updatedUser);
            const path = `users/${currentUser.id}`;
            try {
                await setDoc(doc(db, 'users', currentUser.id), updatedUser, { merge: true });
            } catch (error) {
                handleFirestoreError(error, OperationType.UPDATE, path);
            }
        }
    }, [currentUser]);

    const addShortVideo = useCallback(async (videoData: Omit<ShortVideo, 'id' | 'timestamp' | 'duration'>): Promise<boolean> => {
        if (!currentUser) return false;
        
        const currentVideos = currentUser.videos || [];
        if (currentVideos.length >= 7) {
            alert("You've reached the maximum limit of 7 short videos.");
            return false;
        }

        const newVideo: ShortVideo = {
            ...videoData,
            id: `video-${Date.now()}`,
            timestamp: Date.now(),
            duration: '1:20'
        };

        const updatedUser = {
            ...currentUser,
            videos: [...currentVideos, newVideo]
        };

        setCurrentUser(updatedUser);
        const path = `users/${currentUser.id}`;
        try {
            await setDoc(doc(db, 'users', currentUser.id), updatedUser, { merge: true });
        } catch (error) {
            handleFirestoreError(error, OperationType.UPDATE, path);
        }
        return true;
    }, [currentUser]);

    const updatePlatformSettings = useCallback(async (newSettings: Partial<PlatformSettings>) => {
        setPlatformSettings(prev => ({ ...prev, ...newSettings }));
        const path = 'settings/platform';
        try {
            await setDoc(doc(db, 'settings', 'platform'), newSettings, { merge: true });
        } catch (error) {
            handleFirestoreError(error, OperationType.UPDATE, path);
        }
    }, []);

    const suspendUser = useCallback(async (userId: string) => {
        const creator = userCreators.find(u => u.id === userId);
        if (creator) {
            const updatedCreator = { ...creator, isSuspended: !creator.isSuspended };
            const path = `users/${userId}`;
            try {
                await setDoc(doc(db, 'users', userId), updatedCreator, { merge: true });
            } catch (error) {
                handleFirestoreError(error, OperationType.UPDATE, path);
            }
        }
    }, [userCreators]);

    const topUpCoins = useCallback(async (amount: number) => {
        if (!currentUser) return;
        const updatedUser = { ...currentUser, coins: currentUser.coins + amount };
        setCurrentUser(updatedUser);
        const path = `users/${currentUser.id}`;
        try {
            await setDoc(doc(db, 'users', currentUser.id), updatedUser, { merge: true });
        } catch (error) {
            handleFirestoreError(error, OperationType.UPDATE, path);
        }
        alert(`Successfully added ${amount.toLocaleString()} 💎 to your wallet!`);
    }, [currentUser]);

    const deleteAccount = useCallback(async (): Promise<boolean> => {
        if (!auth.currentUser) return false;
        const userId = auth.currentUser.uid;
        const path = `users/${userId}`;
        try {
            await deleteDoc(doc(db, 'users', userId));
            await deleteUser(auth.currentUser);
            setCurrentUser(null);
            return true;
        } catch (error) {
            console.error("Failed to delete account:", error);
            // If it's a permission error, it will be logged by handleFirestoreError if we called it here.
            // But we want to return false to show the alert in the UI.
            if (error instanceof Error && error.message.includes('insufficient permissions')) {
                handleFirestoreError(error, OperationType.DELETE, path);
            }
            return false;
        }
    }, []);

    const getStreamByCreatorId = useCallback((creatorId: string) => {
        const stream = streams[creatorId] || (allCreators.find(c => c.id === creatorId) || userCreators.find(c => c.id === creatorId)) ? (streams[creatorId] || { creatorId, isLive: false, scheduledTime: null }) as Stream : undefined;
        
        // Automatically "take down" streams older than 5 days
        if (stream && stream.endedAt) {
            const fiveDaysInMs = 5 * 24 * 60 * 60 * 1000;
            if (Date.now() - stream.endedAt > fiveDaysInMs) {
                return undefined;
            }
        }
        
        return stream;
    }, [streams, userCreators, allCreators]);

    const value: AppContextType = {
        creators: [...allCreators, ...userCreators].filter(c => !c.isAdmin),
        userAccounts: userCreators,
        currentUser,
        following,
        streams,
        streamCoinTotals,
        streamGiftEvents,
        platformSettings,
        toggleFollow,
        goLive,
        endStream,
        scheduleStream,
        getStreamByCreatorId,
        signup,
        login,
        logout,
        sendGift,
        supportCreator,
        updateProfileLinks,
        addShortVideo,
        updatePlatformSettings,
        suspendUser,
        topUpCoins,
        deleteAccount,
    };

    return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useApp = (): AppContextType => {
    const context = useContext(AppContext);
    if (context === undefined) {
        throw new Error('useApp must be used within an AppProvider');
    }
    return context;
};
