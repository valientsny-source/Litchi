
import { GoogleGenAI, Type } from "@google/genai";

// Always use const ai = new GoogleGenAI({apiKey: process.env.API_KEY});
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getStreamTitleSuggestions = async (topic: string): Promise<string[]> => {
    try {
        const response = await ai.models.generateContent({
            // Using gemini-3-flash-preview for basic text tasks like suggestion generation
            model: "gemini-3-flash-preview",
            contents: `Generate 5 catchy, short, and exciting titles for a live stream about "${topic}".`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        titles: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.STRING
                            }
                        }
                    },
                    required: ["titles"]
                }
            }
        });
        
        // response.text is a property, not a method.
        const jsonText = response.text.trim();
        const result = JSON.parse(jsonText);
        return result.titles || [];

    } catch (error) {
        console.error("Error fetching title suggestions from Gemini API:", error);
        // Fallback to high-quality mock data if the API call fails
        return [
            `Amazing ${topic} Adventures!`,
            `${topic}: A Deep Dive`,
            `Let's Talk About ${topic}`,
            `The Ultimate ${topic} Guide`,
            `Unboxing the World of ${topic}`
        ];
    }
};
