
export interface ShortVideo {
    id: string;
    title: string;
    thumbnail: string;
    videoUrl: string;
    duration: string; // "1:20"
    timestamp: number;
}

export interface Creator {
    id: string;
    name: string;
    avatar: string;
    followers: number;
    coins: number;
    lifetimeCoins?: number;
    streamCount?: number;
    links?: { title: string; url: string }[];
    videos?: ShortVideo[];
    isAdmin?: boolean;
    isSuspended?: boolean;
}

export interface Stream {
    creatorId: string;
    isLive: boolean;
    scheduledTime: Date | null;
    durationMinutes?: number | null;
    recurrence?: 'daily' | 'weekly' | null;
    endedAt?: number | null;
}

export type View = 'home' | 'following' | 'profile' | 'live' | 'channel' | 'admin';

export interface Gift {
    id: string;
    name: string;
    icon: string;
    cost: number;
}

export interface GiftEvent {
    id: string;
    sender: {
        id: string;
        name: string;
    };
    gift: Gift;
    timestamp: number;
}

export interface PlatformSettings {
    maintenanceMode: boolean;
    disableSignups: boolean;
    globalAlert: string | null;
    isPublished?: boolean;
    monetization?: {
        headCode?: string;
        footerCode?: string;
        feedCode?: string;
    };
}
