
import React, { useState, useCallback, useEffect, useRef } from 'react';
import { auth, db } from './firebase';
import { sendEmailVerification } from 'firebase/auth';
import { AppProvider, useApp } from './contexts/AppContext';

import HomeView from './views/HomeView';
import FollowingView from './views/FollowingView';
import ProfileView from './views/ProfileView';
import LiveStreamView from './views/LiveStreamView';
import CreatorChannelView from './views/CreatorChannelView';
import AdminDashboardView from './views/AdminDashboardView';
import BottomNav from './components/BottomNav';
import Sidebar from './components/Sidebar';
import SearchBar from './components/SearchBar';

import AuthView from './views/AuthView';
import LoginView from './views/LoginView';
import SignUpView from './views/SignUpView';

import type { View } from './types';

const getPath = () => window.location.pathname;

const getViewFromPath = (path: string): [View, string | null] => {
    if (path === '/following') return ['following', null];
    if (path === '/profile') return ['profile', null];
    if (path === '/admin') return ['admin', null];
    const liveMatch = path.match(/^\/live\/([^/]+)/);
    if (liveMatch && liveMatch[1]) return ['live', liveMatch[1]];
    const channelMatch = path.match(/^\/channel\/([^/]+)/);
    if (channelMatch && channelMatch[1]) return ['channel', channelMatch[1]];
    return ['home', null];
};

const LitchiLogo = ({ className = "text-2xl" }) => (
    <h1 className={`${className} font-black select-none tracking-tighter flex items-center cursor-pointer litchi-gradient-text`}>
        litchi
    </h1>
);

export const HtmlInjector: React.FC<{ html: string; className?: string }> = ({ html, className }) => {
    const ref = useRef<HTMLDivElement>(null);
    useEffect(() => {
        if (ref.current) {
            ref.current.innerHTML = '';
            try {
                const fragment = document.createRange().createContextualFragment(html);
                ref.current.appendChild(fragment);
            } catch (e) {
                console.error("Failed to inject HTML:", e);
            }
        }
    }, [html]);
    return <div ref={ref} className={className} />;
};

const AppContent: React.FC = () => {
    const { currentUser, login, signup, goLive, endStream, logout, platformSettings, getStreamByCreatorId } = useApp();
    const [authView, setAuthView] = useState<'main' | 'login' | 'signup' | null>(null);

    const [currentView, setCurrentView] = useState<View>(() => getViewFromPath(getPath())[0]);
    const [activeCreatorId, setActiveCreatorId] = useState<string | null>(() => getViewFromPath(getPath())[1]);
    const [activeSource, setActiveSource] = useState<'camera' | 'screen'>('camera');

    useEffect(() => {
        if (platformSettings.monetization?.headCode) {
            try {
                const fragment = document.createRange().createContextualFragment(platformSettings.monetization.headCode);
                const nodes = Array.from(fragment.childNodes);
                document.head.appendChild(fragment);
                return () => {
                    nodes.forEach(node => {
                        if (document.head.contains(node)) {
                            document.head.removeChild(node);
                        }
                    });
                };
            } catch (e) {
                console.error("Failed to inject head code:", e);
            }
        }
    }, [platformSettings.monetization?.headCode]);

    useEffect(() => {
        const handlePopState = () => {
            const [view, creatorId] = getViewFromPath(getPath());
            setCurrentView(view);
            setActiveCreatorId(creatorId);
        };

        window.addEventListener('popstate', handlePopState);
        return () => window.removeEventListener('popstate', handlePopState);
    }, []);

    const navigate = useCallback((view: View, creatorId: string | null = null) => {
        let path = '/';
        if (view === 'following') path = '/following';
        if (view === 'profile') path = '/profile';
        if (view === 'admin') path = '/admin';
        if (view === 'live' && creatorId) path = `/live/${creatorId}`;
        if (view === 'channel' && creatorId) path = `/channel/${creatorId}`;
        
        if (getPath() !== path) {
            window.history.pushState({ view, creatorId }, '', path);
        }
        setCurrentView(view);
        setActiveCreatorId(creatorId);
    }, []);

    const handleTuneIn = useCallback((creatorId: string) => {
        setActiveSource('camera'); 
        navigate('live', creatorId);
    }, [navigate]);

    const handleGoLive = useCallback((creatorId: string, source: 'camera' | 'screen') => {
        if (!currentUser) {
            setAuthView('main');
            return;
        }
        goLive(creatorId);
        setActiveSource(source);
        navigate('live', creatorId);
    }, [currentUser, goLive, navigate]);
    
    const handleEndStream = useCallback((creatorId: string) => {
        endStream(creatorId);
        navigate('profile');
    }, [endStream, navigate]);

    const handleVisitChannel = useCallback((creatorId: string) => {
        navigate('channel', creatorId);
    }, [navigate]);

    const handleSearchResultClick = useCallback((creatorId: string) => {
        const stream = getStreamByCreatorId(creatorId);
        if (stream?.isLive) {
            handleTuneIn(creatorId);
        } else {
            handleVisitChannel(creatorId);
        }
    }, [getStreamByCreatorId, handleTuneIn, handleVisitChannel]);

    const renderView = () => {
        if (platformSettings.maintenanceMode && !currentUser?.isAdmin) {
            return (
                <div className="flex flex-col items-center justify-center h-[80vh] p-8 text-center animate-pulse">
                    <div className="w-24 h-24 bg-red-900/20 rounded-full flex items-center justify-center mb-6 border border-red-500/30 shadow-xl shadow-red-500/10">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                        </svg>
                    </div>
                    <h2 className="text-3xl font-black mb-4 tracking-tight text-red-400 uppercase italic">System Maintenance</h2>
                    <p className="text-gray-400 mb-8 max-w-sm font-medium">Litchi is currently undergoing scheduled upgrades to improve your streaming experience. We'll be back online shortly.</p>
                    {currentUser && (
                        <button onClick={logout} className="text-gray-500 hover:text-white transition-colors font-bold text-sm uppercase tracking-widest">Logout</button>
                    )}
                </div>
            );
        }

        if ((currentView === 'profile' || currentView === 'following' || currentView === 'admin') && !currentUser) {
            return (
                <div className="flex flex-col items-center justify-center h-[80vh] p-8 text-center animate-slide-up">
                    <div className="w-24 h-24 bg-gray-900 rounded-full flex items-center justify-center mb-6 border border-gray-800 shadow-xl shadow-purple-500/5">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                        </svg>
                    </div>
                    <h2 className="text-3xl font-black mb-4 tracking-tight">Access Restricted</h2>
                    <p className="text-gray-400 mb-8 max-w-sm font-medium">Join the Litchi community to build your fan base, schedule streams, and start your own broadcast.</p>
                    <div className="flex space-x-4">
                        <button 
                            onClick={() => setAuthView('login')}
                            className="bg-gray-900 px-8 py-3 rounded-2xl font-bold border border-gray-800 hover:bg-gray-800 transition-all active:scale-95"
                        >
                            Log In
                        </button>
                        <button 
                            onClick={() => setAuthView('signup')}
                            className="bg-purple-600 px-8 py-3 rounded-2xl font-bold hover:bg-purple-700 transition-all shadow-xl shadow-purple-500/20 active:scale-95"
                        >
                            Sign Up Now
                        </button>
                    </div>
                </div>
            );
        }

        if (currentView === 'live' && activeCreatorId) {
            return <LiveStreamView creatorId={activeCreatorId} onEndStream={handleEndStream} source={activeSource} />;
        }
        if (currentView === 'channel' && activeCreatorId) {
            return <CreatorChannelView creatorId={activeCreatorId} onBack={() => navigate('home')} onTuneIn={handleTuneIn} />;
        }
        if (currentView === 'admin' && currentUser?.isAdmin) {
            return <AdminDashboardView />;
        }
        
        switch (currentView) {
            case 'home':
                return (
                    <HomeView 
                        onTuneIn={handleTuneIn} 
                        onVisitChannel={handleVisitChannel} 
                        onLoginClick={() => setAuthView('login')}
                        onSignUpClick={() => setAuthView('signup')}
                    />
                );
            case 'following':
                return <FollowingView onTuneIn={handleTuneIn} onVisitChannel={handleVisitChannel} />;
            case 'profile':
                return <ProfileView onGoLive={handleGoLive} />;
            default:
                return (
                    <HomeView 
                        onTuneIn={handleTuneIn} 
                        onVisitChannel={handleVisitChannel} 
                        onLoginClick={() => setAuthView('login')}
                        onSignUpClick={() => setAuthView('signup')}
                    />
                );
        }
    };

    const handleLogin = useCallback((creatorId: string) => {
        login(creatorId);
        setAuthView(null);
        if (auth.currentUser?.email === 'maphangabowe@gmail.com') {
            navigate('admin');
        } else {
            navigate('home');
        }
    }, [login, navigate]);

    const handleSignUp = useCallback((name: string) => {
        signup(name);
        setAuthView(null);
        if (auth.currentUser?.email === 'maphangabowe@gmail.com') {
            navigate('admin');
        } else {
            navigate('home');
        }
    }, [signup, navigate]);

    // Global Auth Overlays
    if (authView) {
        switch (authView) {
            case 'login':
                return <LoginView onLogin={handleLogin} onBack={() => setAuthView('main')} onSignUpClick={() => setAuthView('signup')} />;
            case 'signup':
                return <SignUpView onSignUp={handleSignUp} onBack={() => setAuthView('main')} onLoginClick={() => setAuthView('login')} />;
            default:
                return <AuthView onLoginClick={() => setAuthView('login')} onSignUpClick={() => setAuthView('signup')} onCancel={() => setAuthView(null)} />;
        }
    }

    return (
        <div className="min-h-screen w-screen flex flex-col font-sans bg-gray-950 text-white overflow-hidden">
            {/* Standard Website Header */}
            {currentView !== 'live' && (
                <header className="sticky top-0 z-[100] h-16 glass-nav border-b border-gray-900 flex items-center justify-between px-4 md:px-8">
                    <div className="flex items-center flex-1 max-w-4xl">
                        <div onClick={() => navigate('home')} className="mr-2 md:mr-8 shrink-0">
                            <LitchiLogo className="text-xl md:text-3xl" />
                        </div>
                        <SearchBar onResultClick={handleSearchResultClick} />
                    </div>

                    <div className="flex items-center space-x-4 ml-4">
                        {currentUser ? (
                            <>
                                <div className="hidden sm:flex items-center space-x-2 bg-gray-900 border border-gray-800 px-4 py-1.5 rounded-full hover:border-purple-500/40 transition-colors cursor-pointer group">
                                    <span className="text-sm font-black text-white group-hover:text-purple-400 transition-colors">{currentUser.coins.toLocaleString()}</span>
                                    <span className="text-yellow-400 group-hover:animate-bounce">💎</span>
                                </div>
                                <div className="flex items-center space-x-4 ml-4">
                                    <div className="hidden md:block text-right">
                                        <p className="text-xs font-black truncate max-w-[120px]">{currentUser.name}</p>
                                        <button onClick={logout} className="text-[10px] text-gray-500 hover:text-red-400 transition-colors font-black uppercase tracking-[0.2em]">Logout</button>
                                    </div>
                                    <img 
                                        src={currentUser.avatar} 
                                        className="w-10 h-10 rounded-2xl border-2 border-purple-500/40 cursor-pointer hover:scale-110 transition-transform shadow-lg shadow-purple-500/10" 
                                        onClick={() => navigate('profile')}
                                        referrerPolicy="no-referrer"
                                        loading="lazy"
                                    />
                                </div>
                            </>
                        ) : (
                            <div className="flex items-center space-x-3">
                                <button 
                                    onClick={() => setAuthView('login')}
                                    className="px-4 py-2 text-sm font-black text-gray-400 hover:text-white transition-colors uppercase tracking-widest"
                                >
                                    Log In
                                </button>
                                <button 
                                    onClick={() => setAuthView('signup')}
                                    className="px-6 py-2.5 bg-purple-600 text-white font-black rounded-2xl text-sm hover:bg-purple-700 transition-all shadow-xl shadow-purple-500/20 active:scale-95 uppercase tracking-widest"
                                >
                                    Start Now
                                </button>
                            </div>
                        )}
                    </div>
                </header>
            )}

            <div className="flex flex-1 overflow-hidden">
                {currentView !== 'live' && (
                    <Sidebar currentView={currentView} navigate={navigate} />
                )}
                <main className="flex-1 overflow-y-auto bg-gray-950 pb-20 md:pb-0 scroll-smooth no-scrollbar">
                    {renderView()}
                </main>
            </div>
            
            {currentView !== 'live' && (
                <BottomNav currentView={currentView} navigate={navigate} />
            )}
            
            {platformSettings.monetization?.footerCode && (
                <HtmlInjector html={platformSettings.monetization.footerCode} className="w-full" />
            )}
        </div>
    );
};

const App: React.FC = () => {
    return (
        <AppProvider>
            <AppContent />
        </AppProvider>
    );
};

export default App;
